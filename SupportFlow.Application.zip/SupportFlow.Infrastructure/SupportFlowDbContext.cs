using Microsoft.EntityFrameworkCore;
using SupportFlow.Domain;

namespace SupportFlow.Infrastructure;

public sealed class SupportFlowDbContext(DbContextOptions<SupportFlowDbContext> options) : DbContext(options)
{
    public DbSet<Client> Clients => Set<Client>();
    public DbSet<Contact> Contacts => Set<Contact>();
    public DbSet<Ticket> Tickets => Set<Ticket>();
    public DbSet<TicketMessage> TicketMessages => Set<TicketMessage>();
    public DbSet<Notification> Notifications => Set<Notification>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Client>().HasIndex(x => x.ClientCode).IsUnique();
        modelBuilder.Entity<Client>().HasIndex(x => x.Email);
        modelBuilder.Entity<Ticket>().HasIndex(x => x.TicketNumber).IsUnique();
        modelBuilder.Entity<Ticket>().HasIndex(x => new { x.Status, x.Priority });
        modelBuilder.Entity<Ticket>().HasOne(x => x.Client).WithMany(x => x.Tickets).HasForeignKey(x => x.ClientId);
        modelBuilder.Entity<Ticket>().HasOne(x => x.Contact).WithMany().HasForeignKey(x => x.ContactId).OnDelete(DeleteBehavior.NoAction);
        modelBuilder.Entity<TicketMessage>().HasOne(x => x.Ticket).WithMany(x => x.Messages).HasForeignKey(x => x.TicketId);

        var client = new Client
        {
            Id = 1,
            ClientCode = "ACME",
            CompanyName = "Acme Corporation",
            Industry = "Technology",
            Email = "support@acme.example",
            PhoneNumber = "+1-555-0100",
            Address = "1 Innovation Way",
            City = "Austin",
            State = "TX",
            Country = "USA",
            PostalCode = "78701",
            IsActive = true
        };
        modelBuilder.Entity<Client>().HasData(client);
        modelBuilder.Entity<Contact>().HasData(new Contact
        {
            Id = 1,
            ClientId = 1,
            FirstName = "Jordan",
            LastName = "Lee",
            Email = "jordan@acme.example",
            IsPrimary = true,
            IsActive = true
        });
        modelBuilder.Entity<Ticket>().HasData(new Ticket
        {
            Id = 1,
            TicketNumber = "SF-1001",
            Subject = "Unable to sign in",
            Description = "Customer cannot sign in after a password reset.",
            ClientId = 1,
            ContactId = 1,
            Category = "Authentication",
            Priority = "High",
            Status = "Open",
            ResponseDeadline = DateTime.UtcNow.AddHours(2),
            ResolutionDeadline = DateTime.UtcNow.AddHours(8)
        });
    }
}
