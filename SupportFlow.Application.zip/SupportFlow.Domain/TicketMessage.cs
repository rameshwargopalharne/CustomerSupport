namespace SupportFlow.Domain;

public sealed class TicketMessage : BaseEntity
{
    public int TicketId { get; set; }
    public Ticket? Ticket { get; set; }
    public string AuthorId { get; set; } = string.Empty;
    public string AuthorName { get; set; } = string.Empty;
    public string Body { get; set; } = string.Empty;
    public bool IsInternal { get; set; }
}
