namespace SupportFlow.Domain;

public sealed class Contact : BaseEntity
{
    public int ClientId { get; set; }
    public Client? Client { get; set; }
    public string FirstName { get; set; } = string.Empty;
    public string LastName { get; set; } = string.Empty;
    public string Email { get; set; } = string.Empty;
    public string? Phone { get; set; }
    public string? Designation { get; set; }
    public string? Department { get; set; }
    public bool IsPrimary { get; set; }
    public bool IsActive { get; set; } = true;
}
