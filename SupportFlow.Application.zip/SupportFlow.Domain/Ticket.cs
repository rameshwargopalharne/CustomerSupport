namespace SupportFlow.Domain;

public sealed class Ticket : BaseEntity
{
    public string TicketNumber { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public int ClientId { get; set; }
    public Client? Client { get; set; }
    public int ContactId { get; set; }
    public Contact? Contact { get; set; }
    public string Category { get; set; } = "General";
    public string? Subcategory { get; set; }
    public string Priority { get; set; } = "Medium";
    public string Status { get; set; } = "Open";
    public string? AssignedExecutiveId { get; set; }
    public DateTime? ResponseDeadline { get; set; }
    public DateTime? ResolutionDeadline { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public DateTime? ClosedAt { get; set; }
    public ICollection<TicketMessage> Messages { get; set; } = new List<TicketMessage>();
}
