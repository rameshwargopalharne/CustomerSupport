using SupportFlow.Domain;

namespace SupportFlow.Tests;

public class TicketTests
{
    [Fact]
    public void Ticket_DefaultStatus_IsOpen()
    {
        var ticket = new Ticket();
        Assert.Equal("Open", ticket.Status);
    }

    [Fact]
    public void Client_DefaultStatus_IsActive()
    {
        var client = new Client();
        Assert.True(client.IsActive);
    }

    [Fact]
    public void InternalMessage_CanBeMarkedInternal()
    {
        var message = new TicketMessage { IsInternal = true };
        Assert.True(message.IsInternal);
    }
}
