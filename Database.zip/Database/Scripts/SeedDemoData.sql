USE [SupportFlowDB];
GO
-- Execute migrations before running this script.
-- Demo credentials are documented separately and must be reset before production.
