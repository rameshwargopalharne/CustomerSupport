IF DB_ID(N'SupportFlowDB') IS NULL
BEGIN
    CREATE DATABASE [SupportFlowDB];
END;
GO
