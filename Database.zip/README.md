# SupportFlow AI

SupportFlow AI is a React and ASP.NET Core customer support CRM scaffold with live demo authentication, role authorization, client/ticket APIs, dynamic reporting, notifications, and simulated AI endpoints.

## Demo credentials
- Admin: `admin@supportflow.ai` / `Admin123!`
- Support executive: `executive@supportflow.ai` / `Executive123!`
- Client: `client@acme.example` / `Client123!`

## Run
```powershell
dotnet run --project Backend/SupportFlow.API/SupportFlow.API.csproj --urls http://localhost:5141
npm.cmd run dev --prefix Frontend/supportflow-client
```

Frontend: `http://localhost:5173`
Swagger: `http://localhost:5141/swagger`

In development, Vite proxies `/api` requests to `http://localhost:5141`. Set `VITE_API_URL` when the API is hosted at a different origin.
