# Deployment Guide

1. Install IIS, ASP.NET Core Hosting Bundle, SQL Server, and Node.js.
2. Set SQL Server credentials and update `appsettings.Production.json` or environment variables.
3. Run `Deployment\Build.ps1`.
4. Run `Database\Scripts\Create-SupportFlowDB.sql`.
5. Apply EF migrations with `dotnet ef database update`.
6. Run `Deployment\Deploy.ps1` from elevated Windows PowerShell.
7. Configure HTTPS bindings and a CORS origin that matches the React site.
8. Store JWT configuration outside source control using environment variables or secrets.

The API and React build paths are release artifacts. IIS deployment success must be verified with HTTPS and live API requests.
