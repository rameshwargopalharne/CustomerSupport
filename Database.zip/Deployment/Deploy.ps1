param(
    [string]$SiteName = 'SupportFlowAI',
    [string]$ApiPath = 'C:\inetpub\SupportFlowAI\API',
    [string]$ClientPath = 'C:\inetpub\SupportFlowAI\Client'
)
$ErrorActionPreference = 'Stop'
if (-not (Get-Module -ListAvailable -Name WebAdministration)) {
    throw 'WebAdministration module is required. Run this script from an elevated Windows PowerShell on IIS.'
}
Import-Module WebAdministration
New-Item -ItemType Directory -Force -Path $ApiPath, $ClientPath | Out-Null
Copy-Item "$PSScriptRoot\ReleasePackage\API\*" $ApiPath -Recurse -Force
Copy-Item "$PSScriptRoot\ReleasePackage\Client\*" $ClientPath -Recurse -Force
