param([string]$Configuration = 'Release')
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
Set-Location $root
dotnet restore SupportFlowAI.slnx
dotnet test SupportFlowAI.slnx --configuration $Configuration
dotnet publish Backend/SupportFlow.API/SupportFlow.API.csproj --configuration $Configuration --output Deployment/ReleasePackage/API
Push-Location Frontend/supportflow-client
npm ci
npm test
npm run build
Pop-Location
if (Test-Path Deployment/ReleasePackage/Client) { Remove-Item Deployment/ReleasePackage/Client -Recurse -Force }
Copy-Item Frontend/supportflow-client/dist Deployment/ReleasePackage/Client -Recurse
