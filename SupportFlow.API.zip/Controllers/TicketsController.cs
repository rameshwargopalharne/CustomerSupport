using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportFlow.Domain;
using SupportFlow.Infrastructure;

namespace SupportFlow.API.Controllers;

[ApiController]
[Authorize]
[Route("api/tickets")]
public sealed class TicketsController(SupportFlowDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<ActionResult<IEnumerable<Ticket>>> Get([FromQuery] string? status, [FromQuery] string? priority)
    {
        var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
        var email = User.Identity?.Name;
        var query = db.Tickets.AsNoTracking().Include(x => x.Client).Include(x => x.Contact).Where(x => !x.IsDeleted);

        if (role == "SUPPORT_EXECUTIVE")
            query = query.Where(x => x.AssignedExecutiveId == email);
        if (role == "CLIENT")
            query = query.Where(x => x.ClientId == 1);

        if (!string.IsNullOrWhiteSpace(status)) query = query.Where(x => x.Status == status);
        if (!string.IsNullOrWhiteSpace(priority)) query = query.Where(x => x.Priority == priority);
        return Ok(await query.ToListAsync());
    }

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Ticket>> GetById(int id)
    {
        var ticket = await db.Tickets.AsNoTracking().Include(x => x.Client).Include(x => x.Contact)
            .Include(x => x.Messages).FirstOrDefaultAsync(x => x.Id == id);
        if (ticket is null) return NotFound();
        var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
        if (role == "CLIENT")
        {
            ticket.Messages = ticket.Messages.Where(x => !x.IsInternal).ToList();
        }
        return Ok(ticket);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN,CLIENT")]
    public async Task<ActionResult<Ticket>> Create(Ticket ticket)
    {
        if (ticket.ClientId <= 0 || !await db.Clients.AnyAsync(x => x.Id == ticket.ClientId))
            return BadRequest(new { message = "A valid client is required" });
        ticket.TicketNumber = $"SF-{DateTime.UtcNow:yyMMddHHmm}";
        ticket.Status = "Open";
        ticket.ResponseDeadline = DateTime.UtcNow.AddHours(4);
        ticket.ResolutionDeadline = DateTime.UtcNow.AddHours(24);
        db.Tickets.Add(ticket);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = ticket.Id }, ticket);
    }

    [HttpPatch("{id:int}/status")]
    [Authorize(Roles = "ADMIN,SUPPORT_EXECUTIVE")]
    public async Task<IActionResult> UpdateStatus(int id, [FromBody] StatusRequest request)
    {
        var ticket = await db.Tickets.FindAsync(id);
        if (ticket is null) return NotFound();
        var allowed = new HashSet<string> { "Open", "In Progress", "Awaiting Client", "Resolved", "Closed" };
        if (!allowed.Contains(request.Status)) return BadRequest(new { message = "Invalid status" });
        ticket.Status = request.Status;
        ticket.UpdatedAt = DateTime.UtcNow;
        if (request.Status == "Resolved") ticket.ResolvedAt = DateTime.UtcNow;
        if (request.Status == "Closed") ticket.ClosedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Ok(ticket);
    }

    [HttpPost("{id:int}/assign")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Assign(int id, [FromBody] AssignRequest request)
    {
        var ticket = await db.Tickets.FindAsync(id);
        if (ticket is null) return NotFound();
        ticket.AssignedExecutiveId = request.ExecutiveEmail;
        ticket.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return Ok(ticket);
    }

    [HttpPost("{id:int}/messages")]
    [Authorize(Roles = "ADMIN,SUPPORT_EXECUTIVE,CLIENT")]
    public async Task<IActionResult> Message(int id, [FromBody] MessageRequest request)
    {
        var ticket = await db.Tickets.FindAsync(id);
        if (ticket is null) return NotFound();
        var role = User.FindFirst(System.Security.Claims.ClaimTypes.Role)?.Value;
        if (request.IsInternal && role == "CLIENT") return Forbid();
        if (request.IsInternal && role != "ADMIN" && role != "SUPPORT_EXECUTIVE") return Forbid();
        var message = new TicketMessage
        {
            TicketId = id,
            AuthorId = User.Identity?.Name ?? "unknown",
            AuthorName = User.Identity?.Name ?? "Unknown",
            Body = request.Body,
            IsInternal = request.IsInternal
        };
        db.TicketMessages.Add(message);
        await db.SaveChangesAsync();
        return Ok(message);
    }
}

public sealed record StatusRequest(string Status);
public sealed record AssignRequest(string ExecutiveEmail);
public sealed record MessageRequest(string Body, bool IsInternal);
