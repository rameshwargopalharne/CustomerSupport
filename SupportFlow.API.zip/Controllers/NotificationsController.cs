using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportFlow.Domain;
using SupportFlow.Infrastructure;

namespace SupportFlow.API.Controllers;

[ApiController]
[Authorize]
[Route("api/notifications")]
public sealed class NotificationsController(SupportFlowDbContext db) : ControllerBase
{
    [HttpGet]
    public async Task<IActionResult> Get()
    {
        var email = User.Identity?.Name ?? string.Empty;
        var items = await db.Notifications.AsNoTracking()
            .Where(x => x.UserId == email || x.UserId == "*").OrderByDescending(x => x.CreatedAt).ToListAsync();
        return Ok(items);
    }

    [HttpPatch("{id:int}/read")]
    public async Task<IActionResult> MarkRead(int id)
    {
        var item = await db.Notifications.FindAsync(id);
        if (item is null) return NotFound();
        item.IsRead = true;
        await db.SaveChangesAsync();
        return NoContent();
    }
}
