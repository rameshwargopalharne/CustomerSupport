using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using SupportFlow.Infrastructure;

namespace SupportFlow.API.Controllers;

[ApiController]
[Authorize]
[Route("api/reports")]
public sealed class ReportsController(SupportFlowDbContext db) : ControllerBase
{
    [HttpGet("dashboard")]
    public async Task<ActionResult<object>> Dashboard()
    {
        var role = User.FindFirst(ClaimTypes.Role)?.Value;
        var ticketQuery = db.Tickets.AsNoTracking().Where(x => !x.IsDeleted);
        if (role == "SUPPORT_EXECUTIVE")
        {
            var email = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;
            ticketQuery = ticketQuery.Where(x => x.AssignedExecutiveId == email);
        }
        else if (role == "CLIENT")
        {
            ticketQuery = ticketQuery.Where(x => x.ClientId == 1);
        }

        var tickets = await ticketQuery.ToListAsync();
        var clientIds = tickets.Select(x => x.ClientId).Distinct().ToList();
        var clientQuery = db.Clients.AsNoTracking().Where(x => !x.IsDeleted);
        if (role != "ADMIN")
            clientQuery = clientQuery.Where(x => clientIds.Contains(x.Id));
        var clients = await clientQuery.ToListAsync();
        var counts = tickets.GroupBy(x => x.Status).ToDictionary(x => x.Key, x => x.Count());
        var priorities = tickets.GroupBy(x => x.Priority).Select(x => new { name = x.Key, value = x.Count() }).ToList();
        var categories = tickets.GroupBy(x => x.Category).Select(x => new { name = x.Key, value = x.Count() }).ToList();
        var overdue = tickets.Count(x => x.Status != "Resolved" && x.Status != "Closed" &&
            ((x.ResolutionDeadline ?? DateTime.MaxValue) < DateTime.UtcNow));
        var resolved = counts.GetValueOrDefault("Resolved") + counts.GetValueOrDefault("Closed");
        var resolvedWithDeadline = tickets.Where(x => x.ResolvedAt.HasValue && x.ResolutionDeadline.HasValue).ToList();
        var onTime = resolvedWithDeadline.Count(x => x.ResolvedAt <= x.ResolutionDeadline);
        var resolutionDurations = tickets
            .Where(x => x.ResolvedAt.HasValue)
            .Select(x => (x.ResolvedAt!.Value - x.CreatedAt).TotalHours)
            .Where(hours => hours >= 0)
            .ToList();

        return Ok(new
        {
            totalClients = clients.Count,
            activeClients = clients.Count(x => x.IsActive),
            totalTickets = tickets.Count,
            openTickets = counts.GetValueOrDefault("Open"),
            inProgressTickets = counts.GetValueOrDefault("In Progress"),
            awaitingClientTickets = counts.GetValueOrDefault("Awaiting Client"),
            resolvedTickets = counts.GetValueOrDefault("Resolved"),
            closedTickets = counts.GetValueOrDefault("Closed"),
            overdueTickets = overdue,
            slaCompliance = resolvedWithDeadline.Count == 0 ? (int?)null : (int)Math.Round(onTime * 100d / resolvedWithDeadline.Count),
            averageResolutionHours = resolutionDurations.Count == 0 ? (double?)null : Math.Round(resolutionDurations.Average(), 1),
            priorityData = priorities,
            categoryData = categories
        });
    }
}
