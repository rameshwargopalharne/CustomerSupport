using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace SupportFlow.API.Controllers;

[ApiController]
[Authorize(Roles = "ADMIN,SUPPORT_EXECUTIVE")]
[Route("api/ai")]
public sealed class AIController : ControllerBase
{
    [HttpPost("classify-ticket")]
    public ActionResult<object> Classify([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        category = "Technical",
        subcategory = "Authentication",
        priority = "High",
        tags = new[] { "login", "account" },
        explanation = "Demo classification based on keywords. Configure an approved provider for live AI."
    });

    [HttpPost("summarize-ticket")]
    public ActionResult<object> Summarize([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        problemSummary = "The customer reports an access issue.",
        customerImpact = "Unable to use the affected account.",
        actionsTaken = "Ticket and communication history are available for review.",
        currentStatus = "Awaiting human assessment.",
        recommendedNextSteps = "Verify account state and provide a guided recovery response."
    });

    [HttpPost("suggest-reply")]
    public ActionResult<object> SuggestReply([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        reply = "Hello, thank you for contacting SupportFlow AI. We are reviewing your issue and will provide an update shortly.",
        explanation = "Generic fallback response; no external AI provider was configured."
    });

    [HttpPost("recommend-assignment")]
    public ActionResult<object> Assignment([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        recommendations = new[] {
            new { executive = "executive@supportflow.ai", score = 88, explanation = "Lowest current workload and general support availability." }
        }
    });

    [HttpPost("predict-sla-risk")]
    public ActionResult<object> Risk([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        risk = "medium",
        explanation = "Demo estimate based on remaining response time and ticket priority."
    });

    [HttpPost("analyze-sentiment")]
    public ActionResult<object> Sentiment([FromBody] AiTextRequest request) => Ok(new
    {
        mode = "simulated",
        sentiment = "Neutral",
        explanation = "Demo sentiment result; configure an approved AI provider for live analysis."
    });
}

public sealed record AiTextRequest(string? Subject, string? Description, string? Text, int? TicketId);
