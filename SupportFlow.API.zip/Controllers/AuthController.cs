using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace SupportFlow.API.Controllers;

[ApiController]
[Route("api/auth")]
public sealed class AuthController(IConfiguration configuration) : ControllerBase
{
    [HttpPost("login")]
    public ActionResult<object> Login([FromBody] LoginRequest request)
    {
        var demos = new Dictionary<string, (string Password, string Role)>
        {
            ["admin@supportflow.ai"] = ("Admin123!", "ADMIN"),
            ["executive@supportflow.ai"] = ("Executive123!", "SUPPORT_EXECUTIVE"),
            ["client@acme.example"] = ("Client123!", "CLIENT")
        };
        if (!demos.TryGetValue(request.Email.ToLowerInvariant(), out var demo) || demo.Password != request.Password)
            return Unauthorized(new { message = "Invalid credentials" });

        var claims = new[]
        {
            new Claim(ClaimTypes.NameIdentifier, request.Email),
            new Claim(ClaimTypes.Name, request.Email),
            new Claim(ClaimTypes.Role, demo.Role)
        };
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(
            configuration["Jwt:Key"] ?? "SupportFlow-Development-Key-Change-In-Production-2026"));
        var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);
        var token = new JwtSecurityToken(
            configuration["Jwt:Issuer"] ?? "SupportFlowAI",
            configuration["Jwt:Audience"] ?? "SupportFlowAI",
            claims,
            expires: DateTime.UtcNow.AddHours(8),
            signingCredentials: credentials);

        return Ok(new
        {
            accessToken = new JwtSecurityTokenHandler().WriteToken(token),
            role = demo.Role,
            email = request.Email
        });
    }
}

public sealed record LoginRequest(string Email, string Password);
