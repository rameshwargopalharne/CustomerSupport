using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using SupportFlow.Domain;
using SupportFlow.Infrastructure;

namespace SupportFlow.API.Controllers;

[ApiController]
[Authorize]
[Route("api/clients")]
public sealed class ClientsController(SupportFlowDbContext db) : ControllerBase
{
    [HttpGet]
    [Authorize(Roles = "ADMIN,SUPPORT_EXECUTIVE")]
    public async Task<ActionResult<IEnumerable<Client>>> Get()
    {
        return Ok(await db.Clients.AsNoTracking().Where(x => !x.IsDeleted).ToListAsync());
    }

    [HttpGet("{id:int}")]
    [Authorize(Roles = "ADMIN,SUPPORT_EXECUTIVE")]
    public async Task<ActionResult<Client>> GetById(int id)
    {
        var client = await db.Clients.AsNoTracking().Include(x => x.Contacts).FirstOrDefaultAsync(x => x.Id == id && !x.IsDeleted);
        return client is null ? NotFound() : Ok(client);
    }

    [HttpPost]
    [Authorize(Roles = "ADMIN")]
    public async Task<ActionResult<Client>> Create(Client client)
    {
        if (await db.Clients.AnyAsync(x => x.ClientCode == client.ClientCode))
            return Conflict(new { message = "Client code already exists" });
        db.Clients.Add(client);
        await db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetById), new { id = client.Id }, client);
    }

    [HttpPut("{id:int}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Update(int id, Client request)
    {
        var client = await db.Clients.FindAsync(id);
        if (client is null) return NotFound();
        db.Entry(client).CurrentValues.SetValues(request);
        client.UpdatedAt = DateTime.UtcNow;
        await db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [Authorize(Roles = "ADMIN")]
    public async Task<IActionResult> Delete(int id)
    {
        var client = await db.Clients.FindAsync(id);
        if (client is null) return NotFound();
        client.IsDeleted = true;
        client.IsActive = false;
        await db.SaveChangesAsync();
        return NoContent();
    }
}
