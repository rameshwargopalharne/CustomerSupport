import { describe, expect, it } from 'vitest';
import { getAverageResolutionHours, getTicketTrend } from './analytics.js';

describe('ticket analytics', () => {
  it('builds monthly chart counts from ticket timestamps', () => {
    const tickets = [
      { createdAt: '2026-01-10T09:00:00Z', resolvedAt: '2026-01-10T11:00:00Z' },
      { createdAt: '2026-03-05T09:00:00Z' },
      { createdAt: '2025-12-20T09:00:00Z' }
    ];

    const trend = getTicketTrend(tickets, 3, new Date('2026-03-15T12:00:00Z'));

    expect(trend).toHaveLength(3);
    expect(trend.reduce((total, month) => total + month.created, 0)).toBe(2);
    expect(trend.reduce((total, month) => total + month.resolved, 0)).toBe(1);
  });

  it('calculates average time only from valid resolved tickets', () => {
    const tickets = [
      { createdAt: '2026-01-10T09:00:00Z', resolvedAt: '2026-01-10T12:00:00Z' },
      { createdAt: '2026-01-11T09:00:00Z', resolvedAt: '2026-01-11T13:00:00Z' },
      { createdAt: '2026-01-12T09:00:00Z', resolvedAt: '2026-01-12T08:00:00Z' }
    ];

    expect(getAverageResolutionHours(tickets)).toBe(4);
    expect(getAverageResolutionHours([{ createdAt: '2026-01-10T09:00:00Z' }])).toBeNull();
  });
});
