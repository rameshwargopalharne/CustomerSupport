const monthFormat = new Intl.DateTimeFormat(undefined, { month: 'short' });

export function getTicketTrend(tickets, monthCount = 6, now = new Date()) {
  const months = [];
  for (let offset = monthCount - 1; offset >= 0; offset -= 1) {
    const date = new Date(now.getFullYear(), now.getMonth() - offset, 1);
    months.push({
      key: `${date.getFullYear()}-${date.getMonth()}`,
      month: monthFormat.format(date),
      created: 0,
      resolved: 0
    });
  }
  const byKey = new Map(months.map((month) => [month.key, month]));
  tickets.forEach((ticket) => {
    if (ticket.createdAt) {
      const created = new Date(ticket.createdAt);
      const month = byKey.get(`${created.getFullYear()}-${created.getMonth()}`);
      if (month) month.created += 1;
    }
    if (ticket.resolvedAt) {
      const resolved = new Date(ticket.resolvedAt);
      const month = byKey.get(`${resolved.getFullYear()}-${resolved.getMonth()}`);
      if (month) month.resolved += 1;
    }
  });
  return months;
}

export function getAverageResolutionHours(tickets) {
  const durations = tickets
    .filter((ticket) => ticket.resolvedAt && ticket.createdAt)
    .map((ticket) => new Date(ticket.resolvedAt).getTime() - new Date(ticket.createdAt).getTime())
    .filter((duration) => Number.isFinite(duration) && duration >= 0);
  if (!durations.length) return null;
  return Math.round(durations.reduce((total, duration) => total + duration, 0) / durations.length / 3600000);
}
