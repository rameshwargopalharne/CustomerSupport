export function getSession() {
  const raw = localStorage.getItem('supportflow-session');
  return raw ? JSON.parse(raw) : null;
}
