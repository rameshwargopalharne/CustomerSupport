import { useQuery } from '@tanstack/react-query';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import ArrowUpwardRounded from '@mui/icons-material/ArrowUpwardRounded';
import AssignmentTurnedInRounded from '@mui/icons-material/AssignmentTurnedInRounded';
import ConfirmationNumberRounded from '@mui/icons-material/ConfirmationNumberRounded';
import GroupsRounded from '@mui/icons-material/GroupsRounded';
import MoreHorizRounded from '@mui/icons-material/MoreHorizRounded';
import ScheduleRounded from '@mui/icons-material/ScheduleRounded';
import TrendingUpRounded from '@mui/icons-material/TrendingUpRounded';
import WarningAmberRounded from '@mui/icons-material/WarningAmberRounded';
import {
  Alert, Avatar, Box, Button, Card, Chip, Grid, IconButton,
  LinearProgress, Skeleton, Stack, Typography
} from '@mui/material';
import {
  Area, AreaChart, CartesianGrid, Cell, Pie, PieChart,
  ResponsiveContainer, Tooltip, XAxis, YAxis
} from 'recharts';
import { useNavigate } from 'react-router-dom';
import api from '../services/api.js';
import { getSession } from '../utils/session.js';
import { getAverageResolutionHours, getTicketTrend } from '../utils/analytics.js';

const colors = ['#4169e1', '#79a7f8', '#8ad7c0', '#f4bd6a', '#f28f9d'];
const metrics = [
  { key: 'totalTickets', label: 'Total tickets', icon: ConfirmationNumberRounded, tone: '#eaf0ff', color: '#4267d5' },
  { key: 'openTickets', label: 'Open tickets', icon: ScheduleRounded, tone: '#fff3df', color: '#d8942c' },
  { key: 'inProgressTickets', label: 'In progress', icon: TrendingUpRounded, tone: '#e7f7f1', color: '#2a9b79' },
  { key: 'overdueTickets', label: 'Overdue', icon: WarningAmberRounded, tone: '#fff0f1', color: '#df6674' }
];

function greeting() {
  const hour = new Date().getHours();
  return hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
}

function formatTime(date) {
  if (!date) return 'Just now';
  return new Intl.DateTimeFormat(undefined, { month: 'short', day: 'numeric' }).format(new Date(date));
}

function StatusChip({ status }) {
  const palette = {
    Open: { bg: '#fff4df', fg: '#b67a15' },
    'In Progress': { bg: '#edf2ff', fg: '#4666d4' },
    'Awaiting Client': { bg: '#f1ecff', fg: '#7956c7' },
    Resolved: { bg: '#e7f7f1', fg: '#248669' },
    Closed: { bg: '#eef1f5', fg: '#778499' }
  }[status] || { bg: '#eef1f5', fg: '#778499' };
  return <Chip className="status-chip" label={status} size="small" sx={{ bgcolor: palette.bg, color: palette.fg }} />;
}

export default function DashboardPage() {
  const navigate = useNavigate();
  const session = getSession();
  const { data: dashboard, isLoading, error, refetch } = useQuery({
    queryKey: ['dashboard'],
    queryFn: async () => (await api.get('/reports/dashboard')).data
  });
  const { data: tickets = [] } = useQuery({
    queryKey: ['tickets', 'dashboard'],
    queryFn: async () => (await api.get('/tickets')).data
  });

  if (isLoading) return <Stack spacing={2}><Skeleton variant="rounded" height={150} /><Skeleton variant="rounded" height={160} /><Skeleton variant="rounded" height={280} /></Stack>;
  if (error) return <Alert severity="error" action={<Button color="inherit" size="small" onClick={() => refetch()}>Retry</Button>}>Dashboard information could not be loaded.</Alert>;

  const data = getTicketTrend(tickets);
  const averageResolutionHours = getAverageResolutionHours(tickets);
  const trend = [
    { name: 'Open', value: dashboard.openTickets || 0 },
    { name: 'In progress', value: dashboard.inProgressTickets || 0 },
    { name: 'Awaiting', value: dashboard.awaitingClientTickets || 0 },
    { name: 'Resolved', value: dashboard.resolvedTickets || 0 },
    { name: 'Closed', value: dashboard.closedTickets || 0 }
  ];
  const recentTickets = [...tickets].sort((a, b) => new Date(b.updatedAt || b.createdAt) - new Date(a.updatedAt || a.createdAt)).slice(0, 5);
  const firstName = session?.email?.split('@')[0]?.split(/[._-]/)[0] || 'there';
  const isClient = session?.role === 'CLIENT';

  return (
    <Stack spacing={3}>
      <Box className="dashboard-hero">
        <Grid container spacing={2} sx={{ position: 'relative', zIndex: 1, alignItems: 'center' }}>
          <Grid size={{ xs: 12, md: 8 }}>
            <Typography className="hero-eyebrow">{session?.role?.replace('_', ' ')} workspace</Typography>
            <Typography className="hero-title" sx={{ mt: 1 }}>{greeting()}, {firstName} <Box component="span" sx={{ fontSize: 24 }}>✦</Box></Typography>
            <Typography className="hero-subtitle" sx={{ mt: .8 }}>Here’s what’s happening with your support queue today.</Typography>
          </Grid>
          <Grid size={{ xs: 12, md: 4 }} sx={{ display: 'flex', justifyContent: { xs: 'flex-start', md: 'flex-end' }, gap: 1.2 }}>
            {!isClient && <Button variant="contained" onClick={() => navigate('/tickets')} sx={{ bgcolor: '#fff', color: '#3455b5', '&:hover': { bgcolor: '#edf2ff' } }}>View tickets <ArrowForwardRounded sx={{ ml: .6, fontSize: 17 }} /></Button>}
            <Button variant="outlined" onClick={() => navigate('/tickets')} sx={{ color: 'white', borderColor: '#ffffff70', '&:hover': { borderColor: '#fff', bgcolor: '#ffffff12' } }}>Open workspace</Button>
          </Grid>
        </Grid>
      </Box>

      <Grid container spacing={2}>
        {metrics.map((metric, index) => {
          const Icon = metric.icon;
          return (
            <Grid size={{ xs: 12, sm: 6, md: 3 }} key={metric.key}>
              <Card className="metric-card">
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                  <Box className="metric-icon" sx={{ bgcolor: metric.tone, color: metric.color }}><Icon fontSize="small" /></Box>
                  <IconButton size="small"><MoreHorizRounded sx={{ color: '#9aa5b5' }} /></IconButton>
                </Box>
                <Typography className="metric-value">{dashboard[metric.key] ?? 0}</Typography>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: .5 }}>
                  <Typography className="metric-label">{metric.label}</Typography>
                  <Typography sx={{ color: index === 3 ? '#d86774' : '#2c9b78', fontSize: 11, fontWeight: 800, display: 'flex', alignItems: 'center' }}>
                    <ArrowUpwardRounded sx={{ fontSize: 13, mr: .3 }} /> {index === 3 ? 'Needs attention' : 'Live'}
                  </Typography>
                </Box>
              </Card>
            </Grid>
          );
        })}
      </Grid>

      {!isClient && <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card className="chart-card">
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
              <Box><Typography className="section-heading">Ticket activity</Typography><Typography className="chart-note">New and resolved tickets over the last 6 months</Typography></Box>
              <Chip label="Last 6 months" size="small" sx={{ bgcolor: '#f4f6fb', color: '#66758c', fontWeight: 700 }} />
            </Box>
            <Box sx={{ height: 252 }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data} margin={{ left: -18, right: 7, top: 8 }}>
                  <defs>
                    <linearGradient id="createdFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#5576e5" stopOpacity={.2} /><stop offset="100%" stopColor="#5576e5" stopOpacity={0} /></linearGradient>
                    <linearGradient id="resolvedFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#83d8bf" stopOpacity={.22} /><stop offset="100%" stopColor="#83d8bf" stopOpacity={0} /></linearGradient>
                  </defs>
                  <CartesianGrid vertical={false} stroke="#eef1f6" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#9aa5b5', fontSize: 11 }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fill: '#9aa5b5', fontSize: 11 }} />
                  <Tooltip />
                  <Area type="monotone" dataKey="created" name="Created" stroke="#5576e5" strokeWidth={2.5} fill="url(#createdFill)" dot={{ r: 4 }} />
                  <Area type="monotone" dataKey="resolved" name="Resolved" stroke="#70c8ac" strokeWidth={2.5} fill="url(#resolvedFill)" dot={{ r: 4 }} />
                </AreaChart>
              </ResponsiveContainer>
            </Box>
            <Stack direction="row" spacing={2.5} sx={{ justifyContent: 'center', pt: .5 }}>
              <Typography sx={{ fontSize: 11, color: '#778499' }}><Box component="span" sx={{ display: 'inline-block', width: 7, height: 7, borderRadius: '50%', bgcolor: '#5576e5', mr: .8 }} />Created</Typography>
              <Typography sx={{ fontSize: 11, color: '#778499' }}><Box component="span" sx={{ display: 'inline-block', width: 7, height: 7, borderRadius: '50%', bgcolor: '#70c8ac', mr: .8 }} />Resolved</Typography>
            </Stack>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card className="chart-card">
            <Typography className="section-heading">Queue health</Typography>
            <Typography className="chart-note">Tickets by current status</Typography>
            <Box sx={{ height: 192, position: 'relative', mt: 1 }}>
              <ResponsiveContainer width="100%" height="100%">
                <PieChart><Pie data={trend} dataKey="value" nameKey="name" innerRadius={56} outerRadius={78} paddingAngle={4} stroke="none">{trend.map((entry, index) => <Cell key={entry.name} fill={colors[index % colors.length]} />)}</Pie><Tooltip /></PieChart>
              </ResponsiveContainer>
              <Box sx={{ position: 'absolute', inset: 0, display: 'grid', placeContent: 'center', textAlign: 'center', pointerEvents: 'none' }}>
                <Typography sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontWeight: 800, fontSize: 24 }}>{dashboard.totalTickets}</Typography>
                <Typography sx={{ color: '#91a0b4', fontSize: 10 }}>TOTAL</Typography>
              </Box>
            </Box>
            <Stack spacing={1.15} sx={{ mt: .5 }}>
              {trend.map((entry, index) => <Box key={entry.name} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: colors[index] }} />
                <Typography sx={{ flex: 1, fontSize: 11, color: '#718096' }}>{entry.name}</Typography>
                <Typography sx={{ fontSize: 11, color: '#263650', fontWeight: 800 }}>{entry.value}</Typography>
              </Box>)}
            </Stack>
          </Card>
        </Grid>
      </Grid>}

      <Grid container spacing={2}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card>
            <Box className="table-toolbar" sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
              <Box sx={{ flex: 1 }}>
                <Typography className="section-heading">Recent tickets</Typography>
                <Typography className="chart-note">The latest updates from your support queue</Typography>
              </Box>
              <Button endIcon={<ArrowForwardRounded />} onClick={() => navigate('/tickets')} sx={{ color: '#4567d5' }}>View all</Button>
            </Box>
            <Box sx={{ px: 2.5, pb: 1 }}>
              {recentTickets.length ? recentTickets.map((ticket) => (
                <Box key={ticket.id} onClick={() => navigate('/tickets')} sx={{ display: 'flex', alignItems: 'center', gap: 1.5, py: 1.45, borderTop: '1px solid #f0f2f6', cursor: 'pointer', '&:hover': { bgcolor: '#fafbfe' } }}>
                  <Avatar sx={{ width: 35, height: 35, bgcolor: '#eef2ff', color: '#4d67c4', fontSize: 12, fontWeight: 800 }}>{ticket.subject?.[0]?.toUpperCase() || 'T'}</Avatar>
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Typography noWrap sx={{ color: '#263650', fontSize: 12, fontWeight: 700 }}>{ticket.subject}</Typography>
                    <Typography sx={{ color: '#96a1b2', fontSize: 10 }}>{ticket.ticketNumber} · {ticket.client?.companyName || 'Customer'}</Typography>
                  </Box>
                  <StatusChip status={ticket.status} />
                  <Typography sx={{ display: { xs: 'none', sm: 'block' }, color: '#96a1b2', fontSize: 10, minWidth: 52, textAlign: 'right' }}>{formatTime(ticket.updatedAt || ticket.createdAt)}</Typography>
                </Box>
              )) : <Box className="empty-state"><AssignmentTurnedInRounded sx={{ fontSize: 32, color: '#aeb9ca', mb: 1 }} /><Typography fontWeight={700}>All caught up</Typography><Typography fontSize={12}>New tickets will show up here.</Typography></Box>}
            </Box>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card className="chart-card" sx={{ height: '100%' }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <Box><Typography className="section-heading">Service performance</Typography><Typography className="chart-note">SLA compliance this period</Typography></Box>
              <Box className="metric-icon" sx={{ bgcolor: '#e7f7f1', color: '#2a9b79' }}><GroupsRounded fontSize="small" /></Box>
            </Box>
            <Typography sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontSize: 37, fontWeight: 800, mt: 3 }}>{dashboard.slaCompliance ?? 0}<Typography component="span" sx={{ fontSize: 17, color: '#718096', fontWeight: 700 }}>%</Typography></Typography>
            <LinearProgress variant="determinate" value={Math.min(100, dashboard.slaCompliance ?? 0)} sx={{ height: 8, borderRadius: 5, my: 1.5, bgcolor: '#edf1f7', '& .MuiLinearProgress-bar': { borderRadius: 5, bgcolor: '#56bb98' } }} />
            <Typography sx={{ color: '#8794a8', fontSize: 11 }}>Based on ticket resolution data</Typography>
            <DividerLine />
            <Stack direction="row" justifyContent="space-between" sx={{ mt: 1.8 }}>
              <Box><Typography sx={{ color: '#8794a8', fontSize: 10 }}>RESOLVED</Typography><Typography sx={{ fontWeight: 800, fontSize: 16 }}>{dashboard.resolvedTickets ?? 0}</Typography></Box>
              <Box><Typography sx={{ color: '#8794a8', fontSize: 10 }}>AVG. RESOLUTION</Typography><Typography sx={{ fontWeight: 800, fontSize: 16 }}>{averageResolutionHours === null ? '—' : `${averageResolutionHours}h`}</Typography></Box>
              <Box sx={{ color: '#2a9b79', alignSelf: 'center' }}><TrendingUpRounded /></Box>
            </Stack>
          </Card>
        </Grid>
      </Grid>
    </Stack>
  );
}

function DividerLine() {
  return <Box sx={{ borderTop: '1px solid #edf0f5', mt: 2.5 }} />;
}
