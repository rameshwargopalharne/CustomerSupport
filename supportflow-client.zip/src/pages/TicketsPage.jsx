import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import AddRounded from '@mui/icons-material/AddRounded';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import AttachFileRounded from '@mui/icons-material/AttachFileRounded';
import ChatBubbleOutlineRounded from '@mui/icons-material/ChatBubbleOutlineRounded';
import FilterListRounded from '@mui/icons-material/FilterListRounded';
import SearchRounded from '@mui/icons-material/SearchRounded';
import SendRounded from '@mui/icons-material/SendRounded';
import SmartToyRounded from '@mui/icons-material/SmartToyRounded';
import WarningAmberRounded from '@mui/icons-material/WarningAmberRounded';
import {
  Alert, Avatar, Box, Button, Chip, Dialog, DialogActions, DialogContent,
  DialogTitle, Divider, FormControl, FormControlLabel, FormLabel, Grid,
  IconButton, InputAdornment, LinearProgress, MenuItem, Paper, Radio,
  RadioGroup, Skeleton, Stack, Step, StepLabel, Stepper, Table, TableBody,
  TableCell, TableHead, TableRow, TextField, Typography
} from '@mui/material';
import api from '../services/api.js';
import { getSession } from '../utils/session.js';

const pageCurrentTime = Date.now();

const priorities = ['Low', 'Medium', 'High', 'Critical'];
const statuses = ['Open', 'In Progress', 'Awaiting Client', 'Resolved', 'Closed'];

const priorityColors = {
  Low: { bg: '#edf7f3', fg: '#438d72' },
  Medium: { bg: '#edf2ff', fg: '#4e6ac8' },
  High: { bg: '#fff2e4', fg: '#c27b24' },
  Critical: { bg: '#ffedef', fg: '#d15b6b' }
};

function PriorityChip({ priority }) {
  const tone = priorityColors[priority] || priorityColors.Medium;
  return <Chip className="priority-chip" size="small" label={priority} sx={{ bgcolor: tone.bg, color: tone.fg }} />;
}

function StatusChip({ status }) {
  const tone = {
    Open: ['#fff4df', '#b67a15'],
    'In Progress': ['#edf2ff', '#4666d4'],
    'Awaiting Client': ['#f1ecff', '#7956c7'],
    Resolved: ['#e7f7f1', '#248669'],
    Closed: ['#eef1f5', '#778499']
  }[status] || ['#eef1f5', '#778499'];
  return <Chip className="status-chip" size="small" label={status} sx={{ bgcolor: tone[0], color: tone[1] }} />;
}

function timeAgo(value) {
  if (!value) return 'Recently';
  const hours = Math.max(0, Math.floor((pageCurrentTime - new Date(value).getTime()) / 3600000));
  if (hours < 1) return 'Just now';
  if (hours < 24) return `${hours}h ago`;
  return `${Math.floor(hours / 24)}d ago`;
}

const initialTicketForm = {
  subject: '',
  description: '',
  category: 'Product issue',
  subcategory: '',
  priority: '',
  clientId: '',
  contactId: '',
  impact: 'team',
  urgency: 'degraded',
  affectedArea: '',
  errorMessage: '',
  reproductionSteps: '',
  triedAlready: '',
  expectedResult: '',
  environment: ''
};

function suggestedPriority(impact, urgency) {
  if (impact === 'organization' && urgency === 'blocked') return 'Critical';
  if (urgency === 'blocked' || (impact === 'organization' && urgency === 'degraded')) return 'High';
  if (urgency === 'degraded' || impact === 'team') return 'Medium';
  return 'Low';
}

function buildTicketDescription(form) {
  const sections = [
    ['Issue summary', form.description],
    ['Expected result', form.expectedResult],
    ['Business impact', `${form.impact === 'organization' ? 'Organization-wide' : form.impact === 'team' ? 'A team' : 'One person'} affected; ${form.urgency === 'blocked' ? 'work is blocked' : form.urgency === 'degraded' ? 'work is slowed' : 'a workaround is available'}.`],
    ['Affected area', form.affectedArea],
    ['Steps to reproduce', form.reproductionSteps],
    ['Error message', form.errorMessage],
    ['What has already been tried', form.triedAlready],
    ['Environment', form.environment]
  ];
  return sections.filter(([, value]) => value?.trim()).map(([label, value]) => `${label}:\n${value.trim()}`).join('\n\n');
}

export default function TicketsPage() {
  const session = getSession();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedId, setSelectedId] = useState(null);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [priorityFilter, setPriorityFilter] = useState('');
  const [includeInternal, setIncludeInternal] = useState(false);
  const [messageBody, setMessageBody] = useState('');
  const { data = [], isLoading, error } = useQuery({ queryKey: ['tickets'], queryFn: async () => (await api.get('/tickets')).data });
  const { data: selectedTicket, isLoading: detailLoading } = useQuery({
    queryKey: ['ticket', selectedId],
    queryFn: async () => (await api.get(`/tickets/${selectedId}`)).data,
    enabled: Boolean(selectedId)
  });
  const create = useMutation({
    mutationFn: (payload) => api.post('/tickets', payload),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['tickets'] }); queryClient.invalidateQueries({ queryKey: ['dashboard'] }); setDialogOpen(false); }
  });
  const updateStatus = useMutation({
    mutationFn: ({ id, status }) => api.patch(`/tickets/${id}/status`, { status }),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['tickets'] }); queryClient.invalidateQueries({ queryKey: ['ticket', selectedId] }); queryClient.invalidateQueries({ queryKey: ['dashboard'] }); }
  });
  const sendMessage = useMutation({
    mutationFn: ({ id, body, isInternal }) => api.post(`/tickets/${id}/messages`, { body, isInternal }),
    onSuccess: () => { setMessageBody(''); queryClient.invalidateQueries({ queryKey: ['ticket', selectedId] }); }
  });

  const filtered = useMemo(() => data.filter((ticket) => {
    const text = `${ticket.ticketNumber} ${ticket.subject} ${ticket.client?.companyName || ''}`.toLowerCase();
    return text.includes(search.toLowerCase())
      && (!statusFilter || ticket.status === statusFilter)
      && (!priorityFilter || ticket.priority === priorityFilter);
  }), [data, search, statusFilter, priorityFilter]);

  const canCreate = session.role === 'ADMIN' || session.role === 'CLIENT';
  const canRespond = session.role === 'ADMIN' || session.role === 'SUPPORT_EXECUTIVE' || session.role === 'CLIENT';
  const canManage = session.role === 'ADMIN' || session.role === 'SUPPORT_EXECUTIVE';

  if (isLoading) return <Stack spacing={2}><Skeleton variant="rounded" height={100} /><Skeleton variant="rounded" height={420} /></Stack>;
  if (error) return <Alert severity="error">Tickets could not be loaded. Please try again.</Alert>;

  return (
    <Stack spacing={2.5}>
      <Box sx={{ display: 'flex', alignItems: { xs: 'flex-start', sm: 'center' }, flexDirection: { xs: 'column', sm: 'row' }, gap: 1.5 }}>
        <Box sx={{ flex: 1 }}>
          <Typography className="page-kicker">SUPPORT WORKSPACE</Typography>
          <Typography className="page-title" variant="h4" sx={{ mt: .4 }}>Ticket inbox</Typography>
          <Typography sx={{ color: '#8794a8', fontSize: 12, mt: .5 }}>Triage requests and keep every customer conversation moving.</Typography>
        </Box>
        {canCreate && <Button variant="contained" startIcon={<AddRounded />} onClick={() => setDialogOpen(true)}>Create ticket</Button>}
      </Box>

      <Grid container spacing={1.5}>
        {[
          ['All tickets', data.length, '#4169e1', '#edf2ff'],
          ['Open', data.filter((ticket) => ticket.status === 'Open').length, '#c58a2b', '#fff4df'],
          ['In progress', data.filter((ticket) => ticket.status === 'In Progress').length, '#299477', '#e7f7f1'],
          ['Needs attention', data.filter((ticket) => ticket.priority === 'Critical' || (ticket.resolutionDeadline && new Date(ticket.resolutionDeadline).getTime() < pageCurrentTime)).length, '#d15b6b', '#ffedef']
        ].map(([label, count, color, bg]) => <Grid size={{ xs: 6, md: 3 }} key={label}>
          <Paper sx={{ display: 'flex', alignItems: 'center', gap: 1.3, p: 1.7 }}>
            <Box sx={{ width: 35, height: 35, display: 'grid', placeItems: 'center', borderRadius: 2, color, bgcolor: bg }}><ChatBubbleOutlineRounded sx={{ fontSize: 17 }} /></Box>
            <Box><Typography sx={{ fontSize: 19, lineHeight: 1.1, fontWeight: 800, color: '#263650' }}>{count}</Typography><Typography sx={{ color: '#8a97aa', fontSize: 10, mt: .4 }}>{label}</Typography></Box>
          </Paper>
        </Grid>)}
      </Grid>

      <Paper sx={{ overflow: 'hidden' }}>
        <Box className="table-toolbar" sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1.3 }}>
          <Box sx={{ flex: 1, minWidth: 180 }}>
            <Typography component="div" className="section-heading" sx={{ display: 'flex', alignItems: 'center' }}>All tickets <Chip size="small" label={filtered.length} sx={{ ml: .7, height: 20, bgcolor: '#f0f3f9', color: '#718096', fontSize: 10, fontWeight: 800 }} /></Typography>
            <Typography className="chart-note">Search and filter your support queue</Typography>
          </Box>
          <TextField
            placeholder="Search tickets…" value={search} onChange={(event) => setSearch(event.target.value)}
            sx={{ width: { xs: '100%', sm: 220 } }}
            slotProps={{ input: { startAdornment: <InputAdornment position="start"><SearchRounded sx={{ color: '#98a4b5', fontSize: 19 }} /></InputAdornment> } }}
          />
          <TextField select value={statusFilter} onChange={(event) => setStatusFilter(event.target.value)} sx={{ width: 145 }} slotProps={{ select: { displayEmpty: true } }}>
            <MenuItem value="">All statuses</MenuItem>{statuses.map((status) => <MenuItem key={status} value={status}>{status}</MenuItem>)}
          </TextField>
          <TextField select value={priorityFilter} onChange={(event) => setPriorityFilter(event.target.value)} sx={{ width: 130 }} slotProps={{ select: { displayEmpty: true } }}>
            <MenuItem value="">All priorities</MenuItem>{priorities.map((priority) => <MenuItem key={priority} value={priority}>{priority}</MenuItem>)}
          </TextField>
          <IconButton aria-label="Clear filters" onClick={() => { setSearch(''); setStatusFilter(''); setPriorityFilter(''); }} sx={{ border: '1px solid #e8edf4', borderRadius: 2 }}><FilterListRounded sx={{ color: '#75839a' }} /></IconButton>
        </Box>
        <Box sx={{ overflowX: 'auto' }}>
          <Table size="medium" sx={{ minWidth: 820 }}>
            <TableHead className="table-header"><TableRow><TableCell>Ticket</TableCell><TableCell>Customer</TableCell><TableCell>Priority</TableCell><TableCell>Status</TableCell><TableCell>Assignee</TableCell><TableCell>Updated</TableCell><TableCell align="right">SLA deadline</TableCell></TableRow></TableHead>
            <TableBody>
              {filtered.map((ticket) => {
                const overdue = ticket.resolutionDeadline && new Date(ticket.resolutionDeadline).getTime() < pageCurrentTime && !['Resolved', 'Closed'].includes(ticket.status);
                return <TableRow hover key={ticket.id} onClick={() => { setSelectedId(ticket.id); setIncludeInternal(false); }} sx={{ cursor: 'pointer' }}>
                  <TableCell>
                    <Typography className="ticket-subject">{ticket.subject}</Typography>
                    <Typography className="ticket-id">{ticket.ticketNumber} · {ticket.category}</Typography>
                  </TableCell>
                  <TableCell><Typography sx={{ fontSize: 12, color: '#53627a', fontWeight: 600 }}>{ticket.client?.companyName || 'Customer'}</Typography><Typography sx={{ color: '#9aa5b5', fontSize: 10 }}>{ticket.contact?.firstName} {ticket.contact?.lastName}</Typography></TableCell>
                  <TableCell><PriorityChip priority={ticket.priority} /></TableCell>
                  <TableCell><StatusChip status={ticket.status} /></TableCell>
                  <TableCell><Box sx={{ display: 'flex', alignItems: 'center', gap: .8 }}><Avatar sx={{ width: 25, height: 25, fontSize: 9, bgcolor: '#eaf0ff', color: '#506bce' }}>{ticket.assignedExecutiveId?.[0]?.toUpperCase() || '—'}</Avatar><Typography sx={{ fontSize: 11, color: '#718096' }}>{ticket.assignedExecutiveId?.split('@')[0] || 'Unassigned'}</Typography></Box></TableCell>
                  <TableCell><Typography sx={{ fontSize: 11, color: '#718096' }}>{timeAgo(ticket.updatedAt || ticket.createdAt)}</Typography></TableCell>
                  <TableCell align="right">{overdue ? <Chip size="small" icon={<WarningAmberRounded />} label="Overdue" sx={{ bgcolor: '#fff0f1', color: '#d15b6b', fontSize: 10, fontWeight: 800 }} /> : <Typography sx={{ fontSize: 11, color: '#718096' }}>{ticket.resolutionDeadline ? new Date(ticket.resolutionDeadline).toLocaleDateString() : '—'}</Typography>}</TableCell>
                </TableRow>;
              })}
              {!filtered.length && <TableRow><TableCell colSpan={7}><Box className="empty-state"><SearchRounded sx={{ fontSize: 30, color: '#aeb9ca', mb: 1 }} /><Typography fontWeight={700}>No matching tickets</Typography><Typography fontSize={12}>Try a different search or clear the filters.</Typography></Box></TableCell></TableRow>}
            </TableBody>
          </Table>
        </Box>
        <Box sx={{ px: 2.5, py: 1.5, borderTop: '1px solid #edf0f5', display: 'flex', justifyContent: 'space-between' }}>
          <Typography sx={{ fontSize: 10, color: '#97a2b3' }}>Showing {filtered.length} of {data.length} tickets</Typography>
          <Typography sx={{ fontSize: 10, color: '#97a2b3' }}>Updated just now</Typography>
        </Box>
      </Paper>

      {dialogOpen && <TicketCreateDialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        onCreate={(payload) => create.mutate(payload)}
        isPending={create.isPending}
        isError={create.isError}
        role={session.role}
      />}

      <Dialog open={Boolean(selectedId)} onClose={() => setSelectedId(null)} fullWidth maxWidth="md">
        {detailLoading || !selectedTicket ? <DialogContent><Skeleton height={350} /></DialogContent> : <>
          <DialogTitle sx={{ pb: 1 }}>
            <Box sx={{ display: 'flex', alignItems: 'flex-start', gap: 1 }}>
              <Box sx={{ flex: 1 }}><Typography sx={{ color: '#8693a7', fontSize: 10, fontWeight: 800, letterSpacing: '.1em' }}>{selectedTicket.ticketNumber} · {selectedTicket.category}</Typography><Typography sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontWeight: 800, fontSize: 21, mt: .4 }}>{selectedTicket.subject}</Typography></Box>
              <PriorityChip priority={selectedTicket.priority} /><StatusChip status={selectedTicket.status} />
            </Box>
          </DialogTitle>
          <DialogContent sx={{ pt: '10px !important' }}>
            <Grid container spacing={2}>
              <Grid size={{ xs: 12, md: 8 }}>
                <Paper variant="outlined" sx={{ p: 2, bgcolor: '#fafbfe', boxShadow: 'none !important' }}>
                  <Typography sx={{ fontSize: 12, color: '#4c5d76', lineHeight: 1.7 }}>{selectedTicket.description}</Typography>
                </Paper>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 2 }}>
                  <Typography className="section-heading">Conversation</Typography>
                  {canManage && <Button size="small" onClick={() => setIncludeInternal(!includeInternal)} color={includeInternal ? 'warning' : 'inherit'}>{includeInternal ? 'Internal note' : 'Public reply'}</Button>}
                </Box>
                <Box className="conversation-list">
                  {(selectedTicket.messages || []).map((message) => <Box key={message.id} className={`conversation-message ${message.isInternal ? 'internal' : ''} ${message.authorId === session.email ? 'mine' : ''}`}>
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 1, mb: .7 }}><Typography component="div" sx={{ display: 'flex', alignItems: 'center', fontSize: 11, fontWeight: 800 }}>{message.authorName} {message.isInternal && <Chip size="small" label="Internal note" sx={{ height: 18, ml: .6, fontSize: 9, bgcolor: '#ffebbd' }} />}</Typography><Typography sx={{ color: '#9aa5b5', fontSize: 9 }}>{timeAgo(message.createdAt)}</Typography></Box>
                    <Typography sx={{ fontSize: 12, lineHeight: 1.6, color: '#53627a' }}>{message.body}</Typography>
                  </Box>)}
                  {!(selectedTicket.messages || []).length && <Box sx={{ py: 3, textAlign: 'center', color: '#9aa5b5' }}><ChatBubbleOutlineRounded sx={{ fontSize: 25, mb: .5 }} /><Typography sx={{ fontSize: 11 }}>No messages yet. Start the conversation below.</Typography></Box>}
                </Box>
                {canRespond && <Box component="form" onSubmit={(event) => { event.preventDefault(); sendMessage.mutate({ id: selectedId, body: messageBody, isInternal: includeInternal }); }} sx={{ border: '1px solid #e6ebf3', p: 1, borderRadius: 2.5 }}>
                  {includeInternal && <Typography sx={{ color: '#b67a15', fontSize: 10, fontWeight: 800, px: 1, pt: .5 }}>INTERNAL NOTE · VISIBLE TO YOUR TEAM ONLY</Typography>}
                  <TextField fullWidth multiline maxRows={4} variant="standard" placeholder={includeInternal ? 'Write an internal note…' : 'Write a reply…'} value={messageBody} onChange={(event) => setMessageBody(event.target.value)} slotProps={{ input: { disableUnderline: true, sx: { px: 1, py: .5, fontSize: 12 } } }} />
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', px: .5, pt: .6 }}>
                    <Button size="small" startIcon={<AttachFileRounded />} sx={{ color: '#8794a8' }}>Attach</Button>
                    <Button size="small" type="submit" variant="contained" disabled={!messageBody.trim() || sendMessage.isPending} endIcon={<SendRounded />}>{sendMessage.isPending ? 'Sending…' : includeInternal ? 'Add note' : 'Send reply'}</Button>
                  </Box>
                  {sendMessage.isError && <Alert severity="error" sx={{ mt: 1 }}>Message could not be sent.</Alert>}
                </Box>}
              </Grid>
              <Grid size={{ xs: 12, md: 4 }}>
                <Paper variant="outlined" sx={{ p: 2, boxShadow: 'none !important' }}>
                  <Typography className="section-heading" sx={{ mb: 1.5 }}>Ticket details</Typography>
                  <Detail label="Customer" value={selectedTicket.client?.companyName || 'Customer'} />
                  <Detail label="Contact" value={`${selectedTicket.contact?.firstName || ''} ${selectedTicket.contact?.lastName || ''}`.trim() || '—'} />
                  <Detail label="Assigned to" value={selectedTicket.assignedExecutiveId || 'Unassigned'} />
                  <Detail label="Created" value={selectedTicket.createdAt ? new Date(selectedTicket.createdAt).toLocaleDateString() : '—'} />
                  <Divider sx={{ my: 1.5 }} />
                  <Detail label="Response deadline" value={selectedTicket.responseDeadline ? new Date(selectedTicket.responseDeadline).toLocaleString() : '—'} />
                  <Detail label="Resolution deadline" value={selectedTicket.resolutionDeadline ? new Date(selectedTicket.resolutionDeadline).toLocaleString() : '—'} />
                  {canManage && <TextField select fullWidth size="small" label="Update status" value={selectedTicket.status} onChange={(event) => updateStatus.mutate({ id: selectedId, status: event.target.value })} sx={{ mt: 2 }}>
                    {statuses.map((status) => <MenuItem key={status} value={status}>{status}</MenuItem>)}
                  </TextField>}
                  {updateStatus.isError && <Alert severity="error" sx={{ mt: 1 }}>Status could not be updated.</Alert>}
                </Paper>
                <Paper variant="outlined" sx={{ p: 1.8, mt: 1.5, bgcolor: '#f7f8ff', boxShadow: 'none !important' }}>
                  <Box sx={{ display: 'flex', gap: 1, alignItems: 'flex-start' }}><SmartToyRounded sx={{ color: '#647ee0', fontSize: 19, mt: .2 }} /><Box><Typography sx={{ fontSize: 11, fontWeight: 800 }}>AI support assistant</Typography><Typography sx={{ color: '#8794a8', fontSize: 10, lineHeight: 1.5, mt: .5 }}>Demo suggestions are simulated. Review all suggestions before use.</Typography></Box></Box>
                </Paper>
              </Grid>
            </Grid>
          </DialogContent>
          <DialogActions sx={{ px: 3, pb: 2 }}><Button onClick={() => setSelectedId(null)} color="inherit">Close</Button></DialogActions>
        </>}
      </Dialog>
    </Stack>
  );
}

function TicketCreateDialog({ open, onClose, onCreate, isPending, isError, role }) {
  const session = getSession();
  const [step, setStep] = useState(0);
  const [fields, setFields] = useState(initialTicketForm);
  const [validationError, setValidationError] = useState('');
  const isClient = role === 'CLIENT';
  const clientsQuery = useQuery({
    queryKey: ['clients', 'ticket-form'],
    queryFn: async () => (await api.get('/clients')).data,
    enabled: open && !isClient
  });
  const clientId = isClient ? 1 : Number(fields.clientId) || clientsQuery.data?.[0]?.id || 0;
  const clientQuery = useQuery({
    queryKey: ['client', clientId],
    queryFn: async () => (await api.get(`/clients/${clientId}`)).data,
    enabled: open && !isClient && clientId > 0
  });
  const contacts = clientQuery.data?.contacts || [];
  const contactId = Number(fields.contactId) || contacts[0]?.id || 0;
  const currentPriority = suggestedPriority(fields.impact, fields.urgency);
  const update = (key, value) => setFields((previous) => ({ ...previous, [key]: value }));

  const close = () => {
    setStep(0);
    setFields(initialTicketForm);
    setValidationError('');
    onClose();
  };

  const next = () => {
    if (step === 0) {
      if (fields.subject.trim().length < 6) return setValidationError('Use a short, specific title so the team can recognize the issue.');
      if (fields.description.trim().length < 20) return setValidationError('Add a little more detail about what happened (at least 20 characters).');
      if (!fields.category) return setValidationError('Choose the area that best matches this request.');
      if (!isClient && (!clientId || !contactId)) return setValidationError('Choose a customer and contact before continuing.');
    }
    setValidationError('');
    setStep((current) => Math.min(current + 1, 2));
  };

  const submit = () => {
    const priority = fields.priority || currentPriority;
    onCreate({
      subject: fields.subject.trim(),
      description: buildTicketDescription(fields),
      category: fields.category,
      subcategory: fields.subcategory.trim() || null,
      priority,
      clientId,
      contactId
    });
  };

  return (
    <Dialog open={open} onClose={close} fullWidth maxWidth="md">
      <DialogTitle sx={{ px: { xs: 2.5, sm: 3.5 }, pt: 3, pb: 1 }}>
        <Typography sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontWeight: 800, fontSize: 21 }}>Tell us what’s going on</Typography>
        <Typography sx={{ color: '#8794a8', fontSize: 11, mt: .5 }}>A few details help us route your request to the right specialist, faster.</Typography>
      </DialogTitle>
      <DialogContent sx={{ px: { xs: 2.5, sm: 3.5 }, pt: '18px !important' }}>
        <Stepper activeStep={step} alternativeLabel sx={{ mb: 3, '& .MuiStepLabel-label': { fontSize: 10, color: '#8794a8' }, '& .MuiStepLabel-label.Mui-active': { color: '#4169e1', fontWeight: 800 }, '& .MuiStepIcon-root.Mui-active': { color: '#4169e1' }, '& .MuiStepIcon-root.Mui-completed': { color: '#58b899' } }}>
          {['Describe the issue', 'Impact & urgency', 'Review request'].map((label) => <Step key={label}><StepLabel>{label}</StepLabel></Step>)}
        </Stepper>
        <LinearProgress variant="determinate" value={(step + 1) * 33.333} sx={{ height: 3, borderRadius: 2, mb: 2.5, bgcolor: '#edf1f7', '& .MuiLinearProgress-bar': { bgcolor: '#5576e5' } }} />
        {(validationError || isError) && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{validationError || 'Your request could not be submitted. Please try again.'}</Alert>}
        {(clientsQuery.isError || clientQuery.isError) && <Alert severity="error" sx={{ mb: 2 }}>Customer or contact details could not be loaded. Please try again.</Alert>}

        {step === 0 && <Stack spacing={2.2}>
          <Box sx={{ p: 1.6, bgcolor: '#f7f9ff', border: '1px solid #e8edfb', borderRadius: 2.5 }}>
            <Typography sx={{ fontSize: 11, fontWeight: 800, color: '#405baf', mb: 1 }}>START WITH THE BASICS</Typography>
            <Grid container spacing={1.7}>
              <Grid size={{ xs: 12, sm: 6 }}>
                {isClient
                  ? <TextField fullWidth label="Your organization" value="Your organization" disabled />
                  : <TextField select fullWidth label="Customer organization" value={clientId || ''} onChange={(event) => { update('clientId', Number(event.target.value)); update('contactId', ''); }} disabled={clientsQuery.isLoading || !clientsQuery.data?.length}>
                    {(clientsQuery.data || []).map((client) => <MenuItem key={client.id} value={client.id}>{client.companyName} · {client.clientCode}</MenuItem>)}
                  </TextField>}
              </Grid>
              <Grid size={{ xs: 12, sm: 6 }}>
                {isClient
                  ? <TextField fullWidth label="Requesting as" value={session.email} disabled />
                  : <TextField select fullWidth label="Contact" value={contactId || ''} onChange={(event) => update('contactId', Number(event.target.value))} disabled={!contacts.length}>
                    {contacts.map((contact) => <MenuItem key={contact.id} value={contact.id}>{contact.firstName} {contact.lastName} · {contact.email}</MenuItem>)}
                  </TextField>}
              </Grid>
            </Grid>
          </Box>
          <Grid container spacing={1.7}>
            <Grid size={{ xs: 12, sm: 7 }}><TextField fullWidth required label="What do you need help with?" placeholder="Example: I can’t export the monthly invoice report" value={fields.subject} onChange={(event) => update('subject', event.target.value)} helperText="A clear title makes it easier for the right person to pick this up." /></Grid>
            <Grid size={{ xs: 12, sm: 5 }}><TextField select fullWidth label="Product area" value={fields.category} onChange={(event) => update('category', event.target.value)}>
              {['Account & access', 'Billing', 'Product issue', 'Data & reports', 'How-to question', 'Integration', 'Other'].map((category) => <MenuItem value={category} key={category}>{category}</MenuItem>)}
            </TextField></Grid>
            <Grid size={{ xs: 12, sm: 5 }}><TextField fullWidth label="More specific (optional)" placeholder="e.g. Password reset" value={fields.subcategory} onChange={(event) => update('subcategory', event.target.value)} /></Grid>
            <Grid size={{ xs: 12 }}><TextField fullWidth required multiline minRows={3} label="What happened?" placeholder="Tell us what you were doing and what happened instead. Include the page or feature, and when you first noticed the issue." value={fields.description} onChange={(event) => update('description', event.target.value)} helperText={`${fields.description.length}/2000 · Avoid including passwords or sensitive payment details.`} slotProps={{ htmlInput: { maxLength: 2000 } }} /></Grid>
          </Grid>
        </Stack>}

        {step === 1 && <Stack spacing={2.3}>
          <Box><Typography sx={{ fontSize: 14, fontWeight: 800, color: '#283951' }}>Help us understand the impact</Typography><Typography sx={{ color: '#8794a8', fontSize: 11, mt: .4 }}>This helps the support team prioritize fairly. You can review the suggested priority before sending.</Typography></Box>
          <Grid container spacing={2}>
            <Grid size={{ xs: 12, md: 6 }}>
              <FormControl component="fieldset" fullWidth>
                <FormLabel sx={{ color: '#34445e', fontSize: 11, fontWeight: 800, mb: .7 }}>How many people are affected?</FormLabel>
                <RadioGroup value={fields.impact} onChange={(event) => update('impact', event.target.value)}>
                  <FormControlLabel value="person" control={<Radio size="small" />} label={<ChoiceLabel title="Just me" detail="Only one person is affected" />} />
                  <FormControlLabel value="team" control={<Radio size="small" />} label={<ChoiceLabel title="My team" detail="Several people are affected" />} />
                  <FormControlLabel value="organization" control={<Radio size="small" />} label={<ChoiceLabel title="Most of our organization" detail="A widespread service impact" />} />
                </RadioGroup>
              </FormControl>
            </Grid>
            <Grid size={{ xs: 12, md: 6 }}>
              <FormControl component="fieldset" fullWidth>
                <FormLabel sx={{ color: '#34445e', fontSize: 11, fontWeight: 800, mb: .7 }}>How is this affecting your work?</FormLabel>
                <RadioGroup value={fields.urgency} onChange={(event) => update('urgency', event.target.value)}>
                  <FormControlLabel value="workaround" control={<Radio size="small" />} label={<ChoiceLabel title="I can work around it" detail="There is another way to continue" />} />
                  <FormControlLabel value="degraded" control={<Radio size="small" />} label={<ChoiceLabel title="Work is slowed down" detail="Important tasks are taking longer" />} />
                  <FormControlLabel value="blocked" control={<Radio size="small" />} label={<ChoiceLabel title="Work is blocked" detail="A critical task cannot be completed" />} />
                </RadioGroup>
              </FormControl>
            </Grid>
          </Grid>
          <Grid container spacing={1.7}>
            <Grid size={{ xs: 12, sm: 6 }}><TextField fullWidth label="Which part of the product?" placeholder="Page, feature, or workflow" value={fields.affectedArea} onChange={(event) => update('affectedArea', event.target.value)} /></Grid>
            <Grid size={{ xs: 12, sm: 6 }}><TextField fullWidth label="Device or browser (optional)" placeholder="e.g. Chrome on Windows 11" value={fields.environment} onChange={(event) => update('environment', event.target.value)} /></Grid>
            <Grid size={{ xs: 12 }}><TextField fullWidth label="Exact error message (if any)" placeholder="Copy the message you see — please remove personal or secret information." value={fields.errorMessage} onChange={(event) => update('errorMessage', event.target.value)} /></Grid>
            <Grid size={{ xs: 12 }}><TextField fullWidth multiline minRows={2} label="Steps to reproduce (optional)" placeholder="1. Open…  2. Select…  3. The issue occurs when…" value={fields.reproductionSteps} onChange={(event) => update('reproductionSteps', event.target.value)} /></Grid>
            <Grid size={{ xs: 12 }}><TextField fullWidth multiline minRows={2} label="What have you tried so far? (optional)" placeholder="This prevents the support team from asking you to repeat steps." value={fields.triedAlready} onChange={(event) => update('triedAlready', event.target.value)} /></Grid>
            <Grid size={{ xs: 12 }}><TextField fullWidth multiline minRows={2} label="What did you expect to happen? (optional)" placeholder="Describe the result you were expecting." value={fields.expectedResult} onChange={(event) => update('expectedResult', event.target.value)} /></Grid>
          </Grid>
        </Stack>}

        {step === 2 && <Stack spacing={2}>
          <Box sx={{ p: 2, borderRadius: 2.5, bgcolor: '#f7f9ff', border: '1px solid #e8edfb' }}>
            <Typography sx={{ fontSize: 10, fontWeight: 800, color: '#7c8ba3', letterSpacing: '.08em' }}>REQUEST SUMMARY</Typography>
            <Typography sx={{ color: '#253650', fontSize: 15, fontWeight: 800, mt: .7 }}>{fields.subject}</Typography>
            <Typography sx={{ color: '#74839a', fontSize: 11, mt: .7 }}>{fields.category}{fields.subcategory ? ` · ${fields.subcategory}` : ''} · {fields.impact === 'organization' ? 'Organization impact' : fields.impact === 'team' ? 'Team impact' : 'Individual impact'}</Typography>
          </Box>
          <Box sx={{ p: 1.7, borderRadius: 2.5, bgcolor: '#f3f8f6', border: '1px solid #dcefe7' }}>
            <Typography sx={{ color: '#435f56', fontSize: 11, lineHeight: 1.7 }}>{fields.description}</Typography>
          </Box>
          <Grid container spacing={1.7}>
            <Grid size={{ xs: 12, sm: 6 }}><TextField select fullWidth label="Suggested priority · review before sending" value={fields.priority || currentPriority} onChange={(event) => update('priority', event.target.value)}>
              {priorities.map((priority) => <MenuItem key={priority} value={priority}>{priority}{priority === currentPriority ? ' · suggested' : ''}</MenuItem>)}
            </TextField></Grid>
            <Grid size={{ xs: 12, sm: 6 }}><Box sx={{ height: '100%', minHeight: 40, display: 'flex', alignItems: 'center', color: '#8693a7', fontSize: 10 }}>Priority recommendation is based on the impact and urgency you selected. Your support team will confirm it.</Box></Grid>
          </Grid>
          <Alert severity="info" sx={{ borderRadius: 2.5, fontSize: 11 }}>Please do not include passwords, payment card information, or other sensitive credentials in a support request.</Alert>
        </Stack>}
      </DialogContent>
      <DialogActions sx={{ px: { xs: 2.5, sm: 3.5 }, pb: 2.8, pt: 1.5, justifyContent: 'space-between' }}>
        <Button onClick={step ? () => { setStep((current) => current - 1); setValidationError(''); } : close} color="inherit">{step ? 'Back' : 'Cancel'}</Button>
        <Box sx={{ display: 'flex', gap: 1 }}>
          {step < 2
            ? <Button variant="contained" onClick={next} endIcon={<ArrowForwardRounded />}>Continue</Button>
            : <Button variant="contained" onClick={submit} disabled={isPending || (!isClient && (!clientId || !contactId))} endIcon={<ArrowForwardRounded />}>{isPending ? 'Submitting…' : 'Submit request'}</Button>}
        </Box>
      </DialogActions>
    </Dialog>
  );
}

function ChoiceLabel({ title, detail }) {
  return <Box sx={{ py: .35 }}><Typography sx={{ color: '#34445e', fontSize: 11, fontWeight: 700 }}>{title}</Typography><Typography sx={{ color: '#98a3b4', fontSize: 9 }}>{detail}</Typography></Box>;
}

function Detail({ label, value }) {
  return <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 1, py: .7 }}><Typography sx={{ color: '#8b98aa', fontSize: 10 }}>{label}</Typography><Typography sx={{ color: '#34445e', fontSize: 10, fontWeight: 700, textAlign: 'right' }}>{value}</Typography></Box>;
}
