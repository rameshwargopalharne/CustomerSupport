import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Alert, Box, Button, Divider, InputAdornment, Stack, TextField, Typography } from '@mui/material';
import ArrowForwardRounded from '@mui/icons-material/ArrowForwardRounded';
import AutoAwesomeRounded from '@mui/icons-material/AutoAwesomeRounded';
import LockRounded from '@mui/icons-material/LockRounded';
import MailOutlineRounded from '@mui/icons-material/MailOutlineRounded';
import ShieldRounded from '@mui/icons-material/ShieldRounded';
import api from '../services/api.js';

const demoUsers = [
  { role: 'Administrator', email: 'admin@supportflow.ai', password: 'Admin123!', color: '#4969d4', initials: 'AD' },
  { role: 'Support executive', email: 'executive@supportflow.ai', password: 'Executive123!', color: '#2a9b79', initials: 'SE' },
  { role: 'Client', email: 'client@acme.example', password: 'Client123!', color: '#be7c31', initials: 'CL' }
];

export default function LoginPage() {
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: 'admin@supportflow.ai', password: 'Admin123!' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const submit = async (event) => {
    event.preventDefault();
    setLoading(true);
    setError('');
    try {
      const { data } = await api.post('/auth/login', form);
      localStorage.setItem('supportflow-session', JSON.stringify(data));
      navigate('/');
    } catch (e) {
      setError(e.response?.data?.message || 'We could not sign you in. Check your email and password.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box className="login-shell">
      <Box className="login-art">
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.4, position: 'relative', zIndex: 1 }}>
          <Box className="brand-mark" sx={{ bgcolor: '#ffffff22', background: '#ffffff24', boxShadow: 'none' }}>S</Box>
          <Typography sx={{ fontWeight: 800, fontSize: 16 }}>SupportFlow <Box component="span" sx={{ color: '#b9c9ff' }}>AI</Box></Typography>
        </Box>
        <Box sx={{ position: 'relative', zIndex: 1, py: { xs: 2, md: 5 } }}>
          <Box sx={{ display: 'flex', alignItems: 'center', gap: .8, color: '#d8e2ff', mb: 2 }}><AutoAwesomeRounded sx={{ fontSize: 17 }} /><Typography sx={{ fontSize: 11, fontWeight: 800, letterSpacing: '.12em' }}>SUPPORT, IN SYNC</Typography></Box>
          <Typography className="login-art-title">Every customer conversation, moving forward.</Typography>
          <Typography className="login-art-copy" sx={{ mt: 2 }}>A calmer way to handle complex support. Bring tickets, people, and progress into one clear workspace.</Typography>
          <Stack direction="row" spacing={1} sx={{ mt: 4 }}>
            {['One shared inbox', 'AI-assisted insights', 'Customer-first'].map((feature) => <Box key={feature} sx={{ py: .8, px: 1.2, borderRadius: 2, bgcolor: '#ffffff14', border: '1px solid #ffffff20', fontSize: 10, fontWeight: 700 }}>{feature}</Box>)}
          </Stack>
        </Box>
        <Box sx={{ position: 'relative', zIndex: 1, display: 'flex', alignItems: 'center', gap: 1, color: '#d4ddf8' }}>
          <ShieldRounded sx={{ fontSize: 17 }} /><Typography sx={{ fontSize: 11 }}>Secure access for your whole support team</Typography>
        </Box>
      </Box>

      <Box className="login-panel">
        <Box className="login-form">
          <Typography sx={{ color: '#8693a7', fontSize: 11, fontWeight: 800, letterSpacing: '.12em', textTransform: 'uppercase' }}>Welcome back</Typography>
          <Typography sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontSize: 31, fontWeight: 800, letterSpacing: '-.045em', mt: .7 }}>Sign in to your account</Typography>
          <Typography sx={{ color: '#8693a7', fontSize: 13, mt: .5, mb: 3.5 }}>Enter your details to continue to the workspace.</Typography>
          {error && <Alert severity="error" sx={{ mb: 2, borderRadius: 2 }}>{error}</Alert>}
          <Box component="form" onSubmit={submit}>
            <Stack spacing={2}>
              <TextField
                fullWidth label="Work email" type="email" autoComplete="username"
                value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
                slotProps={{ input: { startAdornment: <InputAdornment position="start"><MailOutlineRounded sx={{ color: '#9aa6b8', fontSize: 19 }} /></InputAdornment> } }}
              />
              <TextField
                fullWidth label="Password" type="password" autoComplete="current-password"
                value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
                slotProps={{ input: { startAdornment: <InputAdornment position="start"><LockRounded sx={{ color: '#9aa6b8', fontSize: 19 }} /></InputAdornment> } }}
              />
              <Button fullWidth variant="contained" type="submit" disabled={loading} endIcon={<ArrowForwardRounded />} sx={{ py: 1.35, boxShadow: '0 8px 17px #4169e145' }}>{loading ? 'Signing in…' : 'Sign in'}</Button>
            </Stack>
          </Box>
          <Divider sx={{ my: 3 }}><Typography sx={{ color: '#9aa6b8', fontSize: 10, px: 1 }}>OR TRY A DEMO ACCOUNT</Typography></Divider>
          <Stack spacing={1}>
            {demoUsers.map((user) => (
              <Box key={user.role} className="demo-credential" onClick={() => { setForm({ email: user.email, password: user.password }); setError(''); }} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === 'Enter') setForm({ email: user.email, password: user.password }); }}>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
                  <Box sx={{ width: 31, height: 31, display: 'grid', placeItems: 'center', borderRadius: 2, bgcolor: `${user.color}16`, color: user.color, fontSize: 10, fontWeight: 800 }}>{user.initials}</Box>
                  <Box sx={{ flex: 1 }}><Typography sx={{ fontSize: 11, fontWeight: 800, color: '#293951' }}>{user.role}</Typography><Typography sx={{ fontSize: 10, color: '#8a97aa' }}>{user.email}</Typography></Box>
                  <Typography sx={{ color: '#93a0b2', fontSize: 10 }}>Use demo</Typography>
                </Box>
              </Box>
            ))}
          </Stack>
          <Typography sx={{ textAlign: 'center', color: '#9aa6b8', fontSize: 10, mt: 3 }}>By continuing, you agree to your organization’s security policies.</Typography>
        </Box>
      </Box>
    </Box>
  );
}
