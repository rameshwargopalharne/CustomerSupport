import { useMemo, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import AddRounded from '@mui/icons-material/AddRounded';
import BusinessRounded from '@mui/icons-material/BusinessRounded';
import MoreHorizRounded from '@mui/icons-material/MoreHorizRounded';
import SearchRounded from '@mui/icons-material/SearchRounded';
import SupportAgentRounded from '@mui/icons-material/SupportAgentRounded';
import {
  Alert, Avatar, Box, Button, Chip, Dialog, DialogActions, DialogContent,
  DialogTitle, Grid, IconButton, InputAdornment, Menu, MenuItem, Paper,
  Skeleton, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField,
  Typography
} from '@mui/material';
import api from '../services/api.js';
import { getSession } from '../utils/session.js';

const emptyForm = { clientCode: '', companyName: '', industry: '', email: '', phoneNumber: '', website: '', address: '', city: '', state: '', country: '', postalCode: '', isActive: true };

export default function ClientsPage() {
  const session = getSession();
  const queryClient = useQueryClient();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectedClient, setSelectedClient] = useState(null);
  const [search, setSearch] = useState('');
  const [activeFilter, setActiveFilter] = useState('All clients');
  const [anchor, setAnchor] = useState(null);
  const [menuClient, setMenuClient] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const { data = [], isLoading, error } = useQuery({ queryKey: ['clients'], queryFn: async () => (await api.get('/clients')).data });
  const save = useMutation({
    mutationFn: (payload) => selectedClient ? api.put(`/clients/${selectedClient.id}`, payload) : api.post('/clients', payload),
    onSuccess: () => { queryClient.invalidateQueries({ queryKey: ['clients'] }); setDialogOpen(false); }
  });
  const deactivate = useMutation({
    mutationFn: (id) => api.delete(`/clients/${id}`),
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['clients'] })
  });

  const filtered = useMemo(() => data.filter((client) => {
    const text = `${client.clientCode} ${client.companyName} ${client.industry} ${client.email}`.toLowerCase();
    return text.includes(search.toLowerCase())
      && (activeFilter === 'All clients' || (activeFilter === 'Active' ? client.isActive : !client.isActive));
  }), [data, search, activeFilter]);

  const openCreate = () => { setSelectedClient(null); setForm(emptyForm); setDialogOpen(true); };
  const openEdit = (client) => {
    setSelectedClient(client);
    setForm({ ...emptyForm, ...client });
    setDialogOpen(true);
    setAnchor(null);
  };
  const canManage = session.role === 'ADMIN';

  if (isLoading) return <Stack spacing={2}><Skeleton variant="rounded" height={100} /><Skeleton variant="rounded" height={400} /></Stack>;
  if (error) return <Alert severity="error">Client information could not be loaded.</Alert>;

  return (
    <Stack spacing={2.5}>
      <Box sx={{ display: 'flex', alignItems: { xs: 'flex-start', sm: 'center' }, flexDirection: { xs: 'column', sm: 'row' }, gap: 1.5 }}>
        <Box sx={{ flex: 1 }}>
          <Typography className="page-kicker">CUSTOMER DIRECTORY</Typography>
          <Typography className="page-title" variant="h4" sx={{ mt: .4 }}>Clients</Typography>
          <Typography sx={{ color: '#8794a8', fontSize: 12, mt: .5 }}>Manage organizations and keep customer details close at hand.</Typography>
        </Box>
        {canManage && <Button variant="contained" startIcon={<AddRounded />} onClick={openCreate}>Add client</Button>}
      </Box>

      <Grid container spacing={1.5}>
        <Grid size={{ xs: 12, sm: 4 }}><ClientStat icon={<BusinessRounded />} label="Total organizations" value={data.length} color="#4169e1" bg="#edf2ff" /></Grid>
        <Grid size={{ xs: 12, sm: 4 }}><ClientStat icon={<SupportAgentRounded />} label="Active clients" value={data.filter((client) => client.isActive).length} color="#299477" bg="#e7f7f1" /></Grid>
        <Grid size={{ xs: 12, sm: 4 }}><ClientStat icon={<BusinessRounded />} label="Industries" value={new Set(data.map((client) => client.industry).filter(Boolean)).size} color="#b078ca" bg="#f5edfb" /></Grid>
      </Grid>

      <Paper sx={{ overflow: 'hidden' }}>
        <Box className="table-toolbar" sx={{ display: 'flex', alignItems: 'center', flexWrap: 'wrap', gap: 1.3 }}>
          <Box sx={{ flex: 1 }}>
            <Typography component="div" className="section-heading" sx={{ display: 'flex', alignItems: 'center' }}>Organizations <Chip size="small" label={filtered.length} sx={{ ml: .7, height: 20, bgcolor: '#f0f3f9', color: '#718096', fontSize: 10, fontWeight: 800 }} /></Typography>
            <Typography className="chart-note">Browse and manage your customer accounts</Typography>
          </Box>
          <TextField placeholder="Search clients…" value={search} onChange={(event) => setSearch(event.target.value)} sx={{ width: { xs: '100%', sm: 220 } }} slotProps={{ input: { startAdornment: <InputAdornment position="start"><SearchRounded sx={{ color: '#98a4b5', fontSize: 19 }} /></InputAdornment> } }} />
          <TextField select value={activeFilter} onChange={(event) => setActiveFilter(event.target.value)} sx={{ width: 140 }}>
            {['All clients', 'Active', 'Inactive'].map((value) => <MenuItem key={value} value={value}>{value}</MenuItem>)}
          </TextField>
        </Box>
        <Box sx={{ overflowX: 'auto' }}>
          <Table sx={{ minWidth: 700 }}>
            <TableHead className="table-header"><TableRow><TableCell>Organization</TableCell><TableCell>Industry</TableCell><TableCell>Primary email</TableCell><TableCell>Location</TableCell><TableCell>Status</TableCell><TableCell align="right"> </TableCell></TableRow></TableHead>
            <TableBody>
              {filtered.map((client) => (
                <TableRow hover key={client.id} onClick={() => setSelectedClient(client)} sx={{ cursor: 'pointer' }}>
                  <TableCell>
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 1.2 }}>
                      <Avatar variant="rounded" sx={{ width: 36, height: 36, bgcolor: '#edf2ff', color: '#4d68cc', fontWeight: 800, fontSize: 13, borderRadius: 2 }}>{client.companyName?.slice(0, 1).toUpperCase()}</Avatar>
                      <Box><Typography sx={{ fontSize: 12, color: '#263650', fontWeight: 800 }}>{client.companyName}</Typography><Typography sx={{ color: '#97a2b3', fontSize: 10 }}>{client.clientCode}</Typography></Box>
                    </Box>
                  </TableCell>
                  <TableCell><Chip size="small" label={client.industry || 'General'} sx={{ bgcolor: '#f5f7fb', color: '#66758c', fontSize: 10, fontWeight: 700 }} /></TableCell>
                  <TableCell><Typography sx={{ fontSize: 11, color: '#64738a' }}>{client.email}</Typography></TableCell>
                  <TableCell><Typography sx={{ fontSize: 11, color: '#64738a' }}>{[client.city, client.country].filter(Boolean).join(', ') || '—'}</Typography></TableCell>
                  <TableCell><Chip size="small" label={client.isActive ? 'Active' : 'Inactive'} sx={{ bgcolor: client.isActive ? '#e7f7f1' : '#f0f2f5', color: client.isActive ? '#248669' : '#778499', fontWeight: 800, fontSize: 10 }} /></TableCell>
                  <TableCell align="right" onClick={(event) => event.stopPropagation()}>
                    {canManage && <IconButton size="small" onClick={(event) => { setAnchor(event.currentTarget); setMenuClient(client); }}><MoreHorizRounded sx={{ color: '#8b98aa' }} /></IconButton>}
                  </TableCell>
                </TableRow>
              ))}
              {!filtered.length && <TableRow><TableCell colSpan={6}><Box sx={{ textAlign: 'center', py: 6, color: '#9aa5b5' }}><BusinessRounded sx={{ fontSize: 31, mb: .7 }} /><Typography sx={{ fontSize: 13, fontWeight: 700 }}>No clients found</Typography><Typography sx={{ fontSize: 11 }}>Change your search or add a new organization.</Typography></Box></TableCell></TableRow>}
            </TableBody>
          </Table>
        </Box>
        <Box sx={{ px: 2.5, py: 1.5, borderTop: '1px solid #edf0f5' }}><Typography sx={{ fontSize: 10, color: '#97a2b3' }}>Showing {filtered.length} of {data.length} organizations</Typography></Box>
      </Paper>

      <Menu anchorEl={anchor} open={Boolean(anchor)} onClose={() => setAnchor(null)}>
        <MenuItem onClick={() => openEdit(menuClient)}>Edit organization</MenuItem>
        <MenuItem onClick={() => { deactivate.mutate(menuClient.id); setAnchor(null); }} sx={{ color: '#c14f5d' }}>Deactivate</MenuItem>
      </Menu>
      {deactivate.isError && <Alert severity="error">The client could not be deactivated.</Alert>}

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} fullWidth maxWidth="sm">
        <DialogTitle sx={{ fontFamily: '"Segoe UI", Arial, sans-serif', fontWeight: 800 }}>{selectedClient ? 'Edit organization' : 'Add a client'}</DialogTitle>
        <Typography sx={{ px: 3, color: '#8794a8', fontSize: 12 }}>Keep the organization profile accurate for your support team.</Typography>
        <DialogContent component="form" id="client-form" onSubmit={(event) => { event.preventDefault(); save.mutate(form); }} sx={{ pt: '18px !important' }}>
          {save.isError && <Alert severity="error" sx={{ mb: 2 }}>Could not save this client. Check its code and email address.</Alert>}
          <Grid container spacing={1.7}>
            {[
              ['clientCode', 'Client code'], ['companyName', 'Company name'], ['industry', 'Industry'],
              ['email', 'Email'], ['phoneNumber', 'Phone number'], ['website', 'Website'],
              ['address', 'Address'], ['city', 'City'], ['state', 'State'], ['country', 'Country'], ['postalCode', 'Postal code']
            ].map(([key, label]) => <Grid size={{ xs: 12, sm: key === 'address' ? 12 : 6 }} key={key}>
              <TextField fullWidth required={['clientCode', 'companyName', 'email'].includes(key)} type={key === 'email' ? 'email' : 'text'} label={label} value={form[key] || ''} onChange={(event) => setForm({ ...form, [key]: event.target.value })} />
            </Grid>)}
          </Grid>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}><Button onClick={() => setDialogOpen(false)} color="inherit">Cancel</Button><Button type="submit" form="client-form" variant="contained" disabled={save.isPending}>{save.isPending ? 'Saving…' : selectedClient ? 'Save changes' : 'Create client'}</Button></DialogActions>
      </Dialog>

      <Dialog open={Boolean(selectedClient)} onClose={() => setSelectedClient(null)} fullWidth maxWidth="xs">
        {selectedClient && <><DialogTitle sx={{ pb: 1 }}>
          <Box sx={{ display: 'flex', gap: 1.2, alignItems: 'center' }}><Avatar variant="rounded" sx={{ width: 42, height: 42, bgcolor: '#edf2ff', color: '#4d68cc', fontWeight: 800, borderRadius: 2 }}>{selectedClient.companyName?.[0]}</Avatar><Box><Typography sx={{ fontWeight: 800, fontFamily: '"Segoe UI", Arial, sans-serif' }}>{selectedClient.companyName}</Typography><Typography sx={{ color: '#8794a8', fontSize: 10 }}>{selectedClient.clientCode}</Typography></Box></Box>
        </DialogTitle><DialogContent>
          <Typography sx={{ color: '#8794a8', fontSize: 10, fontWeight: 800, letterSpacing: '.08em', mb: 1 }}>ORGANIZATION PROFILE</Typography>
          <ClientDetail label="Industry" value={selectedClient.industry} />
          <ClientDetail label="Email" value={selectedClient.email} />
          <ClientDetail label="Phone" value={selectedClient.phoneNumber} />
          <ClientDetail label="Website" value={selectedClient.website} />
          <ClientDetail label="Address" value={[selectedClient.address, selectedClient.city, selectedClient.state, selectedClient.country, selectedClient.postalCode].filter(Boolean).join(', ')} />
          <ClientDetail label="Status" value={selectedClient.isActive ? 'Active' : 'Inactive'} />
        </DialogContent><DialogActions><Button onClick={() => setSelectedClient(null)}>Close</Button></DialogActions></>}
      </Dialog>
    </Stack>
  );
}

function ClientStat({ icon, label, value, color, bg }) {
  return <Paper sx={{ display: 'flex', alignItems: 'center', gap: 1.4, p: 1.8 }}><Box sx={{ width: 37, height: 37, display: 'grid', placeItems: 'center', borderRadius: 2, color, bgcolor: bg }}>{icon}</Box><Box><Typography sx={{ fontWeight: 800, fontSize: 19, lineHeight: 1.1 }}>{value}</Typography><Typography sx={{ fontSize: 10, color: '#8794a8', mt: .5 }}>{label}</Typography></Box></Paper>;
}

function ClientDetail({ label, value }) {
  return <Box sx={{ display: 'flex', justifyContent: 'space-between', gap: 2, py: 1, borderBottom: '1px solid #f0f2f6' }}><Typography sx={{ color: '#8b98aa', fontSize: 11 }}>{label}</Typography><Typography sx={{ color: '#34445e', fontSize: 11, fontWeight: 700, textAlign: 'right' }}>{value || '—'}</Typography></Box>;
}
