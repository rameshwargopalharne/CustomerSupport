import { useMemo, useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import ArrowDownwardRounded from '@mui/icons-material/ArrowDownwardRounded';
import ArrowUpwardRounded from '@mui/icons-material/ArrowUpwardRounded';
import DownloadRounded from '@mui/icons-material/DownloadRounded';
import QueryStatsRounded from '@mui/icons-material/QueryStatsRounded';
import ScheduleRounded from '@mui/icons-material/ScheduleRounded';
import TaskAltRounded from '@mui/icons-material/TaskAltRounded';
import WarningAmberRounded from '@mui/icons-material/WarningAmberRounded';
import {
  Alert, Box, Button, Card, Chip, Grid, LinearProgress, MenuItem,
  Skeleton, Stack, TextField, Typography
} from '@mui/material';
import {
  Area, Bar, BarChart, CartesianGrid, Cell, ComposedChart, Legend,
  Pie, PieChart, ResponsiveContainer, Tooltip, XAxis, YAxis
} from 'recharts';
import api from '../services/api.js';
import { getTicketTrend } from '../utils/analytics.js';

const reportAnchorTime = new Date();
const reportCurrentTime = reportAnchorTime.getTime();
const priorityTones = {
  Critical: '#ed7180',
  High: '#efa84d',
  Medium: '#5579e4',
  Low: '#59b998'
};

function StatCard({ title, value, caption, icon, color, background, trend }) {
  return (
    <Card sx={{ p: 2.2, height: '100%' }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <Box sx={{ width: 39, height: 39, display: 'grid', placeItems: 'center', borderRadius: 2.5, color, bgcolor: background }}>{icon}</Box>
        {trend && <Chip size="small" icon={trend.startsWith('-') ? <ArrowDownwardRounded /> : <ArrowUpwardRounded />} label={trend} sx={{ height: 23, bgcolor: '#edf7f3', color: '#318b6d', fontSize: 10, fontWeight: 800, '& .MuiChip-icon': { color: 'inherit', fontSize: 13 } }} />}
      </Box>
      <Typography sx={{ mt: 2, color: '#1e2d45', fontSize: 27, lineHeight: 1.1, fontWeight: 800 }}>{value}</Typography>
      <Typography sx={{ mt: .6, color: '#53627a', fontSize: 11, fontWeight: 700 }}>{title}</Typography>
      <Typography sx={{ mt: .35, color: '#98a3b4', fontSize: 10 }}>{caption}</Typography>
    </Card>
  );
}

export default function InsightsPage() {
  const [months, setMonths] = useState(6);
  const { data: tickets = [], isLoading: ticketsLoading, error: ticketsError, refetch } = useQuery({
    queryKey: ['tickets', 'insights'],
    queryFn: async () => (await api.get('/tickets')).data
  });
  const { data: dashboard, isLoading: reportLoading } = useQuery({
    queryKey: ['dashboard'],
    queryFn: async () => (await api.get('/reports/dashboard')).data
  });

  const since = useMemo(() => {
    const date = new Date(reportAnchorTime);
    date.setMonth(date.getMonth() - months + 1, 1);
    date.setHours(0, 0, 0, 0);
    return date;
  }, [months]);
  const periodTickets = useMemo(() => tickets.filter((ticket) => ticket.createdAt && new Date(ticket.createdAt) >= since), [tickets, since]);
  const trend = useMemo(() => getTicketTrend(periodTickets, months), [periodTickets, months]);
  const categoryData = useMemo(() => {
    const counts = new Map();
    periodTickets.forEach((ticket) => counts.set(ticket.category || 'General', (counts.get(ticket.category || 'General') || 0) + 1));
    return [...counts.entries()].map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value).slice(0, 6);
  }, [periodTickets]);
  const priorityData = useMemo(() => ['Critical', 'High', 'Medium', 'Low'].map((name) => ({
    name,
    value: periodTickets.filter((ticket) => ticket.priority === name).length
  })).filter((item) => item.value > 0), [periodTickets]);

  const resolved = periodTickets.filter((ticket) => ticket.resolvedAt || ticket.status === 'Resolved' || ticket.status === 'Closed');
  const overdue = tickets.filter((ticket) => !['Resolved', 'Closed'].includes(ticket.status) && ticket.resolutionDeadline && new Date(ticket.resolutionDeadline).getTime() < reportCurrentTime).length;
  const breachedResolved = resolved.filter((ticket) => ticket.resolutionDeadline && new Date(ticket.resolvedAt || ticket.updatedAt) > new Date(ticket.resolutionDeadline)).length;
  const compliance = resolved.length ? Math.round(((resolved.length - breachedResolved) / resolved.length) * 100) : null;
  const activeTickets = periodTickets.filter((ticket) => !['Resolved', 'Closed'].includes(ticket.status)).length;

  const exportReport = () => {
    const columns = ['Ticket', 'Subject', 'Category', 'Priority', 'Status', 'Created', 'Resolution deadline'];
    const rows = periodTickets.map((ticket) => [ticket.ticketNumber, ticket.subject, ticket.category, ticket.priority, ticket.status, ticket.createdAt, ticket.resolutionDeadline]);
    const csv = [columns, ...rows].map((row) => row.map((field) => `"${String(field ?? '').replaceAll('"', '""')}"`).join(',')).join('\r\n');
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = `supportflow-insights-${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
  };

  if (ticketsLoading || reportLoading) return <Stack spacing={2}><Skeleton variant="rounded" height={145} /><Skeleton variant="rounded" height={135} /><Skeleton variant="rounded" height={340} /></Stack>;
  if (ticketsError) return <Alert severity="error" action={<Button color="inherit" size="small" onClick={() => refetch()}>Retry</Button>}>Insights could not be loaded.</Alert>;

  return (
    <Stack spacing={2.5}>
      <Box sx={{ display: 'flex', alignItems: { xs: 'flex-start', md: 'center' }, flexDirection: { xs: 'column', md: 'row' }, gap: 1.5 }}>
        <Box sx={{ flex: 1 }}>
          <Typography className="page-kicker">REPORTING & ANALYTICS</Typography>
          <Typography className="page-title" variant="h4" sx={{ mt: .4 }}>Insights</Typography>
          <Typography sx={{ color: '#8794a8', fontSize: 12, mt: .5 }}>A live view of support volume, workload, and service quality.</Typography>
        </Box>
        <TextField select value={months} onChange={(event) => setMonths(Number(event.target.value))} sx={{ minWidth: 150 }}>
          <MenuItem value={6}>Last 6 months</MenuItem><MenuItem value={12}>Last 12 months</MenuItem>
        </TextField>
        <Button variant="contained" startIcon={<DownloadRounded />} onClick={exportReport}>Export report</Button>
      </Box>

      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, px: 1.8, py: 1.1, borderRadius: 2.5, border: '1px solid #e5ebf5', bgcolor: '#fff' }}>
        <QueryStatsRounded sx={{ color: '#5877df', fontSize: 18 }} />
        <Typography sx={{ color: '#607088', fontSize: 10 }}>Metrics are calculated from the tickets visible to your account.</Typography>
        <Box sx={{ flex: 1 }} />
        <Chip size="small" label={`${periodTickets.length} tickets in period`} sx={{ bgcolor: '#edf2ff', color: '#4865cc', fontWeight: 800, fontSize: 10 }} />
      </Box>

      <Grid container spacing={1.7}>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}><StatCard title="Tickets created" value={periodTickets.length} caption={`During the last ${months} months`} icon={<QueryStatsRounded fontSize="small" />} color="#496ce0" background="#edf2ff" /></Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}><StatCard title="Resolved tickets" value={resolved.length} caption="Resolved or closed in the selected set" icon={<TaskAltRounded fontSize="small" />} color="#2a9b79" background="#e7f7f1" /></Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}><StatCard title="Active workload" value={activeTickets} caption="Still open, in progress, or awaiting reply" icon={<ScheduleRounded fontSize="small" />} color="#c58a2b" background="#fff4df" /></Grid>
        <Grid size={{ xs: 12, sm: 6, md: 3 }}><StatCard title="Overdue now" value={overdue} caption="Open tickets past their resolution deadline" icon={<WarningAmberRounded fontSize="small" />} color="#d15b6b" background="#ffedef" /></Grid>
      </Grid>

      <Grid container spacing={1.7}>
        <Grid size={{ xs: 12, lg: 8 }}>
          <Card sx={{ p: 2.4 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', mb: 2 }}>
              <Box><Typography className="section-heading">Ticket volume</Typography><Typography className="chart-note">New tickets and resolved work by month</Typography></Box>
              <Chip size="small" label="Actual ticket history" sx={{ bgcolor: '#f1f4fa', color: '#718096', fontWeight: 700, fontSize: 10 }} />
            </Box>
            <Box sx={{ height: 285 }}>
              {periodTickets.length ? <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={trend} margin={{ left: -18, right: 6, top: 8, bottom: 0 }}>
                  <defs><linearGradient id="insightCreated" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#5576e5" stopOpacity={.2} /><stop offset="100%" stopColor="#5576e5" stopOpacity={0} /></linearGradient></defs>
                  <CartesianGrid vertical={false} stroke="#edf0f5" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#94a0b2', fontSize: 11 }} />
                  <YAxis allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: '#94a0b2', fontSize: 11 }} />
                  <Tooltip />
                  <Legend iconType="circle" wrapperStyle={{ fontSize: 11, color: '#75839a' }} />
                  <Area type="monotone" dataKey="created" name="Created" stroke="#5576e5" strokeWidth={2.5} fill="url(#insightCreated)" dot={{ r: 4 }} />
                  <Bar dataKey="resolved" name="Resolved" fill="#63c3a2" radius={[5, 5, 0, 0]} barSize={20} />
                </ComposedChart>
              </ResponsiveContainer> : <EmptyChart text="Ticket history will appear here as requests arrive." />}
            </Box>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, lg: 4 }}>
          <Card sx={{ p: 2.4, height: '100%' }}>
            <Typography className="section-heading">SLA performance</Typography>
            <Typography className="chart-note">Resolved tickets compared with their deadlines</Typography>
            <Box sx={{ display: 'flex', alignItems: 'baseline', gap: .5, mt: 3 }}>
              <Typography sx={{ color: '#1e2d45', fontSize: 39, lineHeight: 1, fontWeight: 800 }}>{compliance === null ? '—' : compliance}</Typography>
              <Typography sx={{ color: '#8290a6', fontSize: 15, fontWeight: 700 }}>{compliance === null ? '' : '%'}</Typography>
            </Box>
            <LinearProgress variant="determinate" value={compliance ?? 0} sx={{ height: 8, borderRadius: 6, my: 1.5, bgcolor: '#edf1f7', '& .MuiLinearProgress-bar': { borderRadius: 6, bgcolor: '#59bd9b' } }} />
            <Typography sx={{ color: '#98a3b4', fontSize: 10 }}>{compliance === null ? 'Not enough resolved tickets to calculate yet.' : `${resolved.length - breachedResolved} of ${resolved.length} resolved tickets met their deadline.`}</Typography>
            <Box sx={{ mt: 3, p: 1.7, bgcolor: '#fff7e9', borderRadius: 2.5, display: 'flex', gap: 1.2 }}>
              <WarningAmberRounded sx={{ color: '#d59a3d', fontSize: 19 }} />
              <Box><Typography sx={{ fontSize: 11, fontWeight: 800, color: '#6a542d' }}>{overdue} tickets need attention</Typography><Typography sx={{ fontSize: 10, color: '#927a50', mt: .4 }}>Review the queue before the next deadline passes.</Typography></Box>
            </Box>
            <Typography sx={{ color: '#98a3b4', fontSize: 9, mt: 2 }}>SLA is calculated only where a resolution deadline is recorded.</Typography>
          </Card>
        </Grid>
      </Grid>

      <Grid container spacing={1.7}>
        <Grid size={{ xs: 12, md: 7 }}>
          <Card sx={{ p: 2.4, height: '100%' }}>
            <Typography className="section-heading">Requests by category</Typography>
            <Typography className="chart-note">Where customers need the most help</Typography>
            <Box sx={{ height: 245, mt: 1 }}>
              {categoryData.length ? <ResponsiveContainer width="100%" height="100%"><BarChart data={categoryData} layout="vertical" margin={{ left: 12, right: 20, top: 5, bottom: 5 }}>
                <CartesianGrid horizontal={false} stroke="#edf0f5" />
                <XAxis type="number" allowDecimals={false} axisLine={false} tickLine={false} tick={{ fill: '#98a3b4', fontSize: 10 }} />
                <YAxis type="category" dataKey="name" width={95} axisLine={false} tickLine={false} tick={{ fill: '#75839a', fontSize: 10 }} />
                <Tooltip />
                <Bar dataKey="value" name="Tickets" fill="#5877df" radius={[0, 7, 7, 0]} barSize={17} />
              </BarChart></ResponsiveContainer> : <EmptyChart text="Category insights appear after tickets are created." />}
            </Box>
          </Card>
        </Grid>
        <Grid size={{ xs: 12, md: 5 }}>
          <Card sx={{ p: 2.4, height: '100%' }}>
            <Typography className="section-heading">Priority distribution</Typography>
            <Typography className="chart-note">Current ticket mix for this period</Typography>
            <Box sx={{ height: 205, position: 'relative', mt: .5 }}>
              {priorityData.length ? <>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart><Pie data={priorityData} dataKey="value" nameKey="name" innerRadius={58} outerRadius={83} paddingAngle={4} stroke="none">{priorityData.map((item) => <Cell key={item.name} fill={priorityTones[item.name]} />)}</Pie><Tooltip /></PieChart>
                </ResponsiveContainer>
                <Box sx={{ position: 'absolute', inset: 0, display: 'grid', placeContent: 'center', textAlign: 'center', pointerEvents: 'none' }}>
                  <Typography sx={{ fontWeight: 800, fontSize: 25, color: '#24344e' }}>{periodTickets.length}</Typography><Typography sx={{ color: '#98a3b4', fontSize: 9, letterSpacing: '.08em' }}>TICKETS</Typography>
                </Box>
              </> : <EmptyChart text="Priority distribution will appear here." />}
            </Box>
            <Stack spacing={1} sx={{ mt: 1 }}>
              {['Critical', 'High', 'Medium', 'Low'].map((name) => {
                const count = priorityData.find((item) => item.name === name)?.value || 0;
                const percent = periodTickets.length ? Math.round(count * 100 / periodTickets.length) : 0;
                return <Box key={name} sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: priorityTones[name] }} />
                  <Typography sx={{ flex: 1, color: '#75839a', fontSize: 10 }}>{name}</Typography>
                  <Typography sx={{ color: '#34445e', fontSize: 10, fontWeight: 800 }}>{count}</Typography>
                  <Typography sx={{ color: '#9aa5b5', fontSize: 9, width: 32, textAlign: 'right' }}>{percent}%</Typography>
                </Box>;
              })}
            </Stack>
          </Card>
        </Grid>
      </Grid>
      <Typography sx={{ color: '#a0aaba', fontSize: 9, textAlign: 'right' }}>Dashboard data refreshed from SupportFlow APIs · {dashboard?.totalTickets ?? tickets.length} tickets overall</Typography>
    </Stack>
  );
}

function EmptyChart({ text }) {
  return <Box sx={{ height: '100%', display: 'grid', placeContent: 'center', textAlign: 'center', px: 3, color: '#9aa5b5' }}><QueryStatsRounded sx={{ fontSize: 31, mx: 'auto', mb: 1, color: '#bbc5d4' }} /><Typography sx={{ fontSize: 11 }}>{text}</Typography></Box>;
}
