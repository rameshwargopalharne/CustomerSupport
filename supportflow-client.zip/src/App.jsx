import { lazy, Suspense } from 'react';
import { BrowserRouter, Navigate, Route, Routes } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import { Box, CircularProgress, CssBaseline } from '@mui/material';
import LoginPage from './pages/LoginPage.jsx';
import AppLayout from './layouts/AppLayout.jsx';
import { getSession } from './utils/session.js';
import './App.css';

const DashboardPage = lazy(() => import('./pages/DashboardPage.jsx'));
const ClientsPage = lazy(() => import('./pages/ClientsPage.jsx'));
const TicketsPage = lazy(() => import('./pages/TicketsPage.jsx'));
const InsightsPage = lazy(() => import('./pages/InsightsPage.jsx'));

const theme = createTheme({
  palette: { primary: { main: '#4169e1' }, background: { default: '#f5f7fb' }, text: { primary: '#17243b', secondary: '#8290a6' } },
  shape: { borderRadius: 12 },
  typography: { fontFamily: '"Segoe UI", Arial, sans-serif', button: { textTransform: 'none', fontWeight: 700 } },
  components: {
    MuiButton: { styleOverrides: { root: { borderRadius: 10, paddingInline: 16 } } },
    MuiTextField: { defaultProps: { size: 'small' } },
    MuiOutlinedInput: { styleOverrides: { root: { borderRadius: 10 } } }
  }
});
const queryClient = new QueryClient();

function ProtectedRoute({ children, roles }) {
  const session = getSession();
  if (!session) return <Navigate to="/login" replace />;
  if (roles && !roles.includes(session.role)) return <Navigate to="/" replace />;
  return children;
}

function PageLoader() {
  return <Box sx={{ minHeight: 300, display: 'grid', placeItems: 'center' }}><CircularProgress size={30} /></Box>;
}

export default function App() {
  return (
    <ThemeProvider theme={theme}>
      <CssBaseline />
      <QueryClientProvider client={queryClient}>
        <BrowserRouter>
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route element={<ProtectedRoute><AppLayout /></ProtectedRoute>}>
              <Route path="/" element={<Suspense fallback={<PageLoader />}><DashboardPage /></Suspense>} />
              <Route path="/clients" element={<ProtectedRoute roles={['ADMIN', 'SUPPORT_EXECUTIVE']}><Suspense fallback={<PageLoader />}><ClientsPage /></Suspense></ProtectedRoute>} />
              <Route path="/tickets" element={<Suspense fallback={<PageLoader />}><TicketsPage /></Suspense>} />
              <Route path="/insights" element={<ProtectedRoute roles={['ADMIN', 'SUPPORT_EXECUTIVE']}><Suspense fallback={<PageLoader />}><InsightsPage /></Suspense></ProtectedRoute>} />
            </Route>
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </QueryClientProvider>
    </ThemeProvider>
  );
}
