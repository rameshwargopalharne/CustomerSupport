import { useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  Avatar, Badge, Box, Divider, Drawer, IconButton, List, ListItemButton,
  ListItemIcon, ListItemText, Menu, MenuItem, Toolbar, Tooltip, Typography,
  useMediaQuery
} from '@mui/material';
import BusinessRounded from '@mui/icons-material/BusinessRounded';
import DashboardRounded from '@mui/icons-material/DashboardRounded';
import LogoutRounded from '@mui/icons-material/LogoutRounded';
import MenuRounded from '@mui/icons-material/MenuRounded';
import NotificationsNoneRounded from '@mui/icons-material/NotificationsNoneRounded';
import QueryStatsRounded from '@mui/icons-material/QueryStatsRounded';
import ConfirmationNumberRounded from '@mui/icons-material/ConfirmationNumberRounded';
import { useTheme } from '@mui/material/styles';
import { getSession } from '../utils/session.js';
import api from '../services/api.js';

const drawerWidth = 250;
const navGroups = [
  {
    label: 'WORKSPACE',
    links: [
      { title: 'Overview', path: '/', icon: DashboardRounded },
      { title: 'Tickets', path: '/tickets', icon: ConfirmationNumberRounded },
      { title: 'Clients', path: '/clients', icon: BusinessRounded, hideForClient: true }
    ]
  },
  {
    label: 'MANAGE',
    links: [
      { title: 'Insights', path: '/insights', icon: QueryStatsRounded, hideForClient: true }
    ]
  }
];

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [mobileOpen, setMobileOpen] = useState(false);
  const [notificationAnchor, setNotificationAnchor] = useState(null);
  const session = getSession();
  const { data: notifications = [] } = useQuery({
    queryKey: ['notifications'],
    queryFn: async () => (await api.get('/notifications')).data,
    staleTime: 30000
  });
  const unread = notifications.filter((item) => !item.isRead).length;
  const pageTitle = location.pathname === '/tickets' ? 'Tickets' : location.pathname === '/clients' ? 'Clients' : location.pathname === '/insights' ? 'Insights' : 'Overview';

  const logout = () => {
    localStorage.removeItem('supportflow-session');
    navigate('/login');
  };

  const drawer = (
    <Box className="workspace-sidebar" sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <Toolbar sx={{ px: '22px !important', minHeight: '76px !important', gap: 1.5 }}>
        <Box className="brand-mark">S</Box>
        <Box>
          <Typography sx={{ fontWeight: 800, fontSize: 15, letterSpacing: '-.03em' }}>SupportFlow</Typography>
          <Typography sx={{ color: '#8190aa', fontSize: 10, fontWeight: 700, letterSpacing: '.12em' }}>AI SERVICE DESK</Typography>
        </Box>
      </Toolbar>
      <Divider sx={{ borderColor: '#ffffff12', mx: 2 }} />
      <List className="workspace-nav" sx={{ px: 1, pt: 1.5 }}>
        {navGroups.map((group) => (
          <Box key={group.label}>
            <Box className="nav-caption">{group.label}</Box>
            {group.links.filter((link) => !(link.hideForClient && session?.role === 'CLIENT')).map((link) => {
              const Icon = link.icon;
              return (
                <ListItemButton
                  key={`${group.label}-${link.title}`}
                  selected={location.pathname === link.path}
                  onClick={() => { navigate(link.path); setMobileOpen(false); }}
                >
                  <ListItemIcon><Icon fontSize="small" /></ListItemIcon>
                  <ListItemText primary={link.title} />
                </ListItemButton>
              );
            })}
          </Box>
        ))}
      </List>
      <Box sx={{ flex: 1 }} />
      <Box sx={{ p: 1.5 }}>
        <Box sx={{ borderRadius: 3, p: 1.5, bgcolor: '#ffffff0d', display: 'flex', alignItems: 'center', gap: 1.3 }}>
          <Avatar sx={{ width: 34, height: 34, bgcolor: '#526fe2', fontSize: 13, fontWeight: 800 }}>{session?.email?.[0]?.toUpperCase() || 'S'}</Avatar>
          <Box sx={{ minWidth: 0, flex: 1 }}>
            <Typography noWrap sx={{ color: 'white', fontSize: 11, fontWeight: 700 }}>{session?.email}</Typography>
            <Typography sx={{ color: '#8594ad', fontSize: 10 }}>{session?.role?.replace('_', ' ')}</Typography>
          </Box>
          <Tooltip title="Sign out"><IconButton size="small" onClick={logout} sx={{ color: '#9eacc2' }}><LogoutRounded fontSize="small" /></IconButton></Tooltip>
        </Box>
      </Box>
    </Box>
  );

  return (
    <Box className="workspace" sx={{ display: 'flex' }}>
      <Box component="nav" sx={{ width: { md: drawerWidth }, flexShrink: { md: 0 } }}>
        {isMobile ? (
          <Drawer variant="temporary" open={mobileOpen} onClose={() => setMobileOpen(false)} ModalProps={{ keepMounted: true }} sx={{ '& .MuiDrawer-paper': { width: drawerWidth, border: 0 } }}>{drawer}</Drawer>
        ) : (
          <Drawer variant="permanent" open sx={{ '& .MuiDrawer-paper': { width: drawerWidth, border: 0, boxSizing: 'border-box' } }}>{drawer}</Drawer>
        )}
      </Box>
      <Box component="main" sx={{ flexGrow: 1, minWidth: 0 }}>
        <Box className="topbar" sx={{ height: 76, display: 'flex', alignItems: 'center', px: { xs: 2, md: 4 }, gap: 1.5, position: 'sticky', top: 0, zIndex: 5 }}>
          {isMobile && <IconButton onClick={() => setMobileOpen(true)}><MenuRounded /></IconButton>}
          <Box>
            <Typography sx={{ fontSize: 11, color: '#94a0b2', fontWeight: 600 }}>SupportFlow / <Box component="span" sx={{ color: '#52627a' }}>{pageTitle}</Box></Typography>
            <Typography sx={{ fontSize: 16, fontWeight: 800, color: '#17243b' }}>{pageTitle}</Typography>
          </Box>
          <Box sx={{ flex: 1 }} />
          <Tooltip title="Notifications">
            <IconButton onClick={(event) => setNotificationAnchor(event.currentTarget)}>
              <Badge badgeContent={unread} color="error"><NotificationsNoneRounded /></Badge>
            </IconButton>
          </Tooltip>
          <Menu anchorEl={notificationAnchor} open={Boolean(notificationAnchor)} onClose={() => setNotificationAnchor(null)} PaperProps={{ sx: { width: 320, maxHeight: 420, mt: 1.5, borderRadius: 3 } }}>
            <Box sx={{ px: 2, py: 1.3 }}><Typography fontWeight={800}>Notifications</Typography></Box>
            <Divider />
            {notifications.length ? notifications.slice(0, 6).map((item) => <MenuItem key={item.id} onClick={() => { setNotificationAnchor(null); api.patch(`/notifications/${item.id}/read`).catch(() => {}); }} sx={{ whiteSpace: 'normal', py: 1.2 }}><Box><Typography fontSize={13} fontWeight={700}>{item.title}</Typography><Typography fontSize={11} color="text.secondary">{item.message}</Typography></Box></MenuItem>) : <MenuItem disabled>No new notifications</MenuItem>}
          </Menu>
          <Avatar sx={{ width: 34, height: 34, bgcolor: '#eaf0ff', color: '#3559c7', fontWeight: 800, fontSize: 13 }}>{session?.email?.[0]?.toUpperCase()}</Avatar>
        </Box>
        <Box className="page-container"><Outlet /></Box>
      </Box>
    </Box>
  );
}
