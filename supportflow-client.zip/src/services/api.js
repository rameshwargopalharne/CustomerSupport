import axios from 'axios';

const configuredApiUrl = import.meta.env.VITE_API_URL?.replace(/\/+$/, '');
const baseURL = configuredApiUrl
  ? (configuredApiUrl.endsWith('/api') ? configuredApiUrl : `${configuredApiUrl}/api`)
  : '/api';

const api = axios.create({
  baseURL
});

api.interceptors.request.use((config) => {
  const raw = localStorage.getItem('supportflow-session');
  if (raw) {
    const session = JSON.parse(raw);
    config.headers.Authorization = `Bearer ${session.accessToken}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('supportflow-session');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

export default api;
